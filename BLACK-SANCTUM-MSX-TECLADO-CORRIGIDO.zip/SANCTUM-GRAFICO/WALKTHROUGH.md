# Solucao completa — MSX Graphic Edition

Este percurso foi executado literalmente no openMSX/C-BIOS MSX1 e MSX2, ate a vitoria. Sao 230 comandos, visitando 24/24 salas, inclusive o aprisionamento. E uma solucao completa, nao uma rota minima.

Digite uma linha por vez e ENTER. Quando aparecer `[tecla para continuar]`, pressione uma tecla e continue; essa tecla nao faz parte do roteiro. Os comandos historicos em ingles evitam ambiguidades entre L=LOOK e leste=E. O inventario permite cinco objetos.

Os objetos deixados no chao permanecem no local. Nao recolha outros itens alem dos indicados, pois isso altera o espaco disponivel. A lanterna termina este percurso com 29 acoes de combustivel.

## 1. Montanha, cabana, bilhete e espelho

Visite os pinheiros, entre na cabana, deixe a pa na sala de estar e feche a porta. A prateleira esconde os fosforos. A jovem segura o bilhete com a invocacao. A quebra deliberada do espelho visita a sala 24; a invocacao permite retornar. Voce termina no corredor 9.

Comandos 1 a 24:

```text
N
S
E
GO CABIN
GET SHOVEL
OPEN DOOR
GO DOOR
DROP SHOVEL
CLOSE DOOR
LOOK MANTLE
GET MATCHES
GET WINE
GET NET
GO STAIRS
LOOK WOMAN
GET NOTE
READ NOTE
DROP NOTE
GO CLOSET
GET ROBE
BREAK MIRROR
INVOCARE EPISCOPUS
GO MIRROR
S
```

## 2. Estantes e lanterna

Procure duas vezes nas estantes: os dois documentos sao revelados separadamente. Deixe rede e fosforos no estudio para liberar espaco; a partitura e o vinho continuam com voce. Recolha a lanterna na alcova 23.

Comandos 25 a 39:

```text
E
N
LOOK BOOKS
LOOK BOOKS
GET PARCHMENT
READ PARCHMENT
DROP NET
DROP MATCHES
GET MANUSCRIPT
READ MANUSCRIPT
DROP MANUSCRIPT
E
S
E
GET LANTERN
```

## 3. Vinho, ferramentas e porta do mosteiro

O velho esta no sotao 18. Dar o vinho equivale a deixa-lo para o velho beber. Ele leva a garrafa vazia para a sala 15. Deixe a partitura temporariamente no sotao, recolha as ferramentas, volte a 9, destranque a porta e deixe as chaves ali.

Comandos 40 a 58:

```text
W
N
N
N
W
S
GO STAIRS
GIVE WINE
DROP PARCHMENT
GET KEYS
GET SHEARS
GET SAW
D
N
E
S
E
UNLOCK DOOR
DROP KEYS
```

## 4. Cabelo e lencol antes da transformacao

Volte pelo espelho. Corte e recolha a mecha ANTES de recolher neve com a garrafa: esse segundo evento transforma a mulher em estatua. Deixe tesoura no quarto e cabelo/lencol na sala de estar para transportar depois.

Comandos 59 a 68:

```text
N
GO MIRROR
W
CUT HAIR
GET HAIR
DROP SHEARS
GET SHEET
D
DROP HAIR
DROP SHEET
```

## 5. Recuperar a garrafa e tocar Bach

Busque a partitura no sotao e a garrafa vazia na sala 15. Entre pela porta destrancada de 9 e toque BACH. GO PASSAGE atravessa a abertura do orgao para 11. Deixe a partitura nessa sala; ela ja cumpriu seu papel.

Comandos 69 a 87:

```text
GO STAIRS
GO CLOSET
GO MIRROR
S
E
S
S
GO STAIRS
GET PARCHMENT
D
N
E
GET JUG
S
E
GO DOOR
PLAY BACH
GO PASSAGE
DROP PARCHMENT
```

## 6. Lanterna, caixao e instrucoes do bispo

Busque os fosforos no estudio, acenda a lanterna e deixe os fosforos ali para liberar uma posicao. Atravesse o duto ate 12 e siga ao norte para 13. Deixe o serrote, pegue o martelo, abra o caixao e ouca o bispo. Deixe a garrafa na cripta por enquanto.

Comandos 88 a 105:

```text
GO PASSAGE
N
E
N
GET MATCHES
LIGHT LANTERN
DROP MATCHES
S
W
GO DOOR
GO PASSAGE
GO VENT
N
DROP SAW
GET HAMMER
OPEN COFFIN
LISTEN
DROP JUG
```

## 7. Tabuas, pregos e altar

Retorne pela rota dos corredores ate a alcova 23. Retire os pregos com o martelo e leve tabuas/pregos pela porta agora livre ate 12 e 13. As tabuas nao passam pelo duto; essa porta e essencial. O serrote ja esta no chao da cripta. Construa o altar, deixe o martelo e recupere a garrafa.

Comandos 106 a 122:

```text
S
GO VENT
GO PASSAGE
N
E
N
E
S
E
PULL NAILS
GET BOARDS
GET NAILS
GO DOOR
N
BUILD ALTAR
DROP HAMMER
GET JUG
```

## 8. Pena e sal

Apague a lanterna fora da passagem escura. Recolha sal e recupere a rede do estudio. Deixe objetos temporariamente no chao para respeitar cinco posicoes, capture o corvo e retire uma pena. Recupere os fosforos para acender a lanterna antes de voltar ao subterraneo. Deixe pena e sal na cripta e saia para apagar a luz em seguranca.

Comandos 123 a 163:

```text
S
GO VENT
UNLIGHT LANTERN
GET SALT
GO PASSAGE
N
E
N
GET NET
S
W
GO DOOR
GO PASSAGE
DROP JUG
GET RAVEN
DROP SALT
GET FEATHER
DROP RAVEN
DROP NET
GET SALT
GET JUG
GO PASSAGE
N
E
N
DROP SALT
GET MATCHES
LIGHT LANTERN
DROP MATCHES
GET SALT
S
W
GO DOOR
GO PASSAGE
GO VENT
N
DROP FEATHER
DROP SALT
S
GO VENT
UNLIGHT LANTERN
```

## 9. Agua pura

Volte a cabana. A pa ainda esta na sala de estar. Abra a porta, cave a neve e saia. Encha a garrafa com neve; oeste leva aos pinheiros da sala 1, onde se recolhem as agulhas. Retorne pela entrada da cabana: a neve derrete automaticamente na sala aquecida. Recolha a mecha que voce deixou ali.

Comandos 164 a 180:

```text
GO PASSAGE
N
N
GO MIRROR
W
D
GET SHOVEL
OPEN DOOR
DIG SNOW
GO DOOR
DROP SHOVEL
GET SNOW
W
GET NEEDLES
GO CABIN
GO DOOR
GET HAIR
```

## 10. Transportar cabelo, agulhas e agua

Volte ao estudio. Deixe a mecha no chao apenas para pegar fosforos e acender a lanterna; recupere a mecha depois de deixar os fosforos. Leve os ingredientes a cripta. Deixe cabelo, agulhas e garrafa de agua ali.

Comandos 181 a 200:

```text
GO STAIRS
GO CLOSET
GO MIRROR
S
E
N
DROP HAIR
GET MATCHES
LIGHT LANTERN
DROP MATCHES
GET HAIR
S
W
GO DOOR
GO PASSAGE
GO VENT
N
DROP HAIR
DROP NEEDLES
DROP JUG
```

## 11. Lencol e consagracao

Ainda falta o lencol branco. Volte a cabana com a lanterna apagada e recupere-o na sala de estar. Antes de entrar de novo no subterraneo, acenda a lanterna com os fosforos do estudio. Ao chegar a cripta, os ingredientes reunidos e o altar fazem a consagracao acontecer automaticamente. Surgem as cinzas.

Comandos 201 a 225:

```text
S
GO VENT
UNLIGHT LANTERN
GO PASSAGE
N
N
GO MIRROR
W
D
GET SHEET
GO STAIRS
GO CLOSET
GO MIRROR
S
E
N
GET MATCHES
LIGHT LANTERN
DROP MATCHES
S
W
GO DOOR
GO PASSAGE
GO VENT
N
```

## 12. Cinzas e invocacao imediata

Recolha as cinzas, volte ao circulo de sal e jogue-as. O comando IMEDIATAMENTE seguinte deve ser INVOCARE EPISCOPUS. Nao intercale LOOK, INVENTORY, SAVE ou outro comando. A mensagem final confirma VOCE VENCEU!

Comandos 226 a 230:

```text
GET ASH
S
GO VENT
DROP ASH
INVOCARE EPISCOPUS
```

