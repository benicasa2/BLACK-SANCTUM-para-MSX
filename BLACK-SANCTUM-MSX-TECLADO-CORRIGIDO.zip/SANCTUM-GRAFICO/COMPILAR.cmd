@echo off
setlocal
cd /d "%~dp0"
sjasmplus -Wno-fileorg --raw=SANCTUM-GFX-TECLADO-CORRIGIDO.rom --sym=SANCTUM-GFX.sym SANCTUM-GFX.asm
if errorlevel 1 exit /b 1
echo ROM compilada: SANCTUM-GFX-TECLADO-CORRIGIDO.rom
