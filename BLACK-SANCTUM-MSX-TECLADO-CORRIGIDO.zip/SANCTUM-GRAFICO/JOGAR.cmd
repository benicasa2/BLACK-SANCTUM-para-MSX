@echo off
setlocal
cd /d "%~dp0"
openmsx -cart SANCTUM-GFX-TECLADO-CORRIGIDO.rom -romtype ASCII16
