# Formato dos gráficos

O Assembly principal inclui `assets/tables.inc`, `assets/font.bin` e os bancos `bank01.bin` a `bank12.bin`. Esses arquivos são dados completos de montagem; os PNGs são prévias, não dependências de execução.

Cada registro de `asset_table` tem sete bytes:

```text
DB banco
DW endereco_na_janela_8000_BFFF
DB x_em_tiles, y_em_tiles, largura_em_tiles, altura_em_tiles
```

Após a descompressão, vem primeiro o plano de padrões e depois o de cores. Cada plano tem `largura × altura × 8` bytes. Ordem: linhas de tiles, colunas de tiles, oito linhas de cada tile. O tamanho máximo é 7.168 bytes, para uma cena de 32×14 tiles.

O decompressor aceita:

| Código | Dados seguintes | Efeito |
|---|---|---|
| 0 | nenhum | Fim |
| 1–127 | essa quantidade de bytes | Literal |
| 129–191 | um byte | Repetir `código−128` vezes |
| 192–255 | distância de 16 bits, little endian | Copiar `(código AND 63)+3` bytes já produzidos, com sobreposição permitida |

O compressor não emite o código 128. Nenhum asset cruza o limite de um banco ROM. Os endereços da tabela são relativos à janela do banco selecionado; não são offsets no arquivo ROM inteiro.

`base_assets` aponta a base de cada sala. `object_art` associa sala, ID histórico de objeto e asset de atualização. Nas salas 5, 11 e 18, `combo5_assets`, `combo11_assets` e `combo18_assets` substituem camadas independentes por composições completas, pois objetos distintos podem compartilhar o mesmo tile.

Bits das variantes:

- Sala 5: porta aberta, rede presente, garrafa presente, fósforos visíveis, neve bloqueando.
- Sala 18: velho foi embora, chaves presentes, tesoura presente, serrote presente.
- Sala 11: corvo presente, pena presente, mulher transformada; dois bits adicionais selecionam normal, encapuzado, fogo da vitória ou petrificação.

O nome de cada asset e seu registro estão em `assets/manifest.json`. A fonte de caracteres contém os glifos ASCII 32–127, com oito bytes por glifo. A tabela de nomes do SCREEN 2 é sequencial, permitindo endereçar tanto arte quanto texto por linha de tile.

## Fonte menor

Os glifos usam cinco colunas por sete linhas, nas colunas 1–5 dos tiles. As colunas 0, 6 e 7, e a linha 7, ficam vazias. `fonte-5x7.py` gera `font.bin` ao ser executado dentro desta pasta ou de qualquer outro diretório. Letras minúsculas usam o mesmo desenho das maiúsculas.
