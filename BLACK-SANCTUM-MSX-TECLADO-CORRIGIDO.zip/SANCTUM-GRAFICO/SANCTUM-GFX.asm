; THE BLACK SANCTUM - MSX GRAPHIC EDITION
; Porte autoral Z80 baseado nos fontes 8086 fornecidos pelo usuario.
; Original: Bob Withers & Stephen O'Dea / Mark Data Products, 1981-1987.
; Logica derivada de ADVCODE2 e ADVDATA2. Graficos derivados de SCREENS
; e ADVOVL1; conversao SCREEN 2, Scale2x, iluminacao e texturas novas.
; SjASMPlus, cartucho ASCII16 de 256 KB. RAM minima: 64 KB.
    ORG $4000
    DB "AB"
    DW start,0,0,0,0,0,0
CHGMOD EQU $005F
CHGCLR EQU $0062
WRTVRM EQU $004D
FILVRM EQU $0056
LDIRVM EQU $005C
REPCNT EQU $F3F7 ; Contador de repeticao automatica do BIOS
CHSNS EQU $009C
CHGET EQU $009F
WRTPSG EQU $0093
RSLREG EQU $0138
ENASLT EQU $0024
; Estado serializavel em C000-C1FF; copia SAVE em C400-C5FF.
room EQU $C000
lit EQU $C001
fuel EQU $C002
paid EQU $C003
played EQU $C004
cabdoor EQU $C005
chapdoor EQU $C006
boards EQU $C007
coffin EQU $C008
voice EQU $C009             ; 0 desconhecido,1 ouvido,2 cinzas,3 risco imediato
altar EQU $C00A
snowwall EQU $C00B
transformed EQU $C00C
jug EQU $C00D               ; 0 vinho,1 vazio,2 neve,3 agua
haircut EQU $C00E
won EQU $C00F               ; 0 jogo,1 vitoria,2 morte
turns EQU $C010             ; contador de 16 bits
verb EQU $C012
noun EQU $C013
msg EQU $C014               ; ponteiro de resposta (DW)
nptr EQU $C016
seed EQU $C018
saved EQU $C019
textrow EQU $C020
textcol EQU $C021
asset_x EQU $C022
asset_y EQU $C023
asset_w EQU $C024
asset_h EQU $C025
asset_len EQU $C026         ; bytes de um plano
asset_dst EQU $C028
asset_src EQU $C02A
gfxptr EQU $C02C
animtick EQU $C02E
animframe EQU $C02F
buffer EQU $C040            ; 32 caracteres + zero
loc EQU $C100               ; indexado pelo ID original 0..127
scratch EQU $C800           ; max 7168 bytes descomprimidos (ate E3FF)
; Pagina 1 fixa: banco 0. Pagina 2: janela de graficos ASCII16.
start:
    di
    ld sp,$F000
    ld hl,$C000
    ld de,$C001
    ld bc,$01FF
    ld (hl),0
    ldir
    xor a
    ld ($C600),a
    ld hl,initial_loc
    ld de,loc
    ld bc,128
    ldir
    ld a,1
    ld (room),a
    ld a,100
    ld (fuel),a
    ld a,37
    ld (seed),a
    ; Descobre o slot primario/secundario do cartucho na pagina 1.
    ; Preserva pagina 0 (BIOS) e pagina 3 (RAM/stack).
    ei
    call RSLREG
    rrca
    rrca
    and 3
    ld c,a
    ld b,0
    ld hl,$FCC1           ; EXPTBL
    add hl,bc
    ld a,(hl)
    and $80
    or c
    ld c,a
    inc hl
    inc hl
    inc hl
    inc hl               ; SLTTBL do mesmo slot primario
    ld a,(hl)
    and $0C              ; subslot selecionado na pagina 1
    or c
    ld h,$80
    call ENASLT
    xor a
    ld ($6000),a         ; fixa banco 0 em 4000-7FFF
    ld a,1
    ld ($7000),a         ; banco grafico em 8000-BFFF
    ld a,15
    ld ($F3E9),a
    ld a,1
    ld ($F3EA),a
    ld ($F3EB),a
    ld a,2
    call CHGMOD
    call CHGCLR
    ; Nome sequencial dos 768 tiles: 0..255 em cada terco da tela.
    ld hl,scratch
    ld bc,768
    xor a
.names:
    ld (hl),a
    inc a
    inc hl
    dec bc
    ld d,a
    ld a,b
    or c
    ld a,d
    jr nz,.names
    ld hl,scratch
    ld de,$1800
    ld bc,768
    call LDIRVM
    ; Sprite 0: floco/luz. Demais sprites inicialmente ocultos.
    ld hl,spark_pattern
    ld de,$3800
    ld bc,32
    call LDIRVM
    ld hl,$1B00
    ld bc,128
    ld a,216
    call FILVRM
    ld hl,m_welcome
    ld (msg),hl
main:
    ld a,(won)
    or a
    jr z,.normal
    call show_graphics
    call clear_text
    jr .reply
.normal:
    call show_room
.reply:
    ld hl,(msg)
    call puts
    ld hl,m_empty
    ld (msg),hl
    ld a,(won)
    or a
    jp nz,ending
    call input_line
    call parse
    ; Depois das cinzas no circulo, so a invocacao imediata salva.
    ld a,(voice)
    cp 3
    jr nz,.dispatch
    ld a,(verb)
    cp 37
    jr nz,.fatal
    ld a,(noun)
    cp 39
    jr z,.dispatch
.fatal:
    ld a,2
    ld (won),a
    ld hl,m_stone
    ld (msg),hl
    jp main
.dispatch:
    call dispatch
    call after_turn
    jp main
ending:
    ld hl,m_restart
    call puts
.key:
    call CHGET
    and $DF
    cp 'R'
    jp z,start
    jr .key
; ---------------------- VIDEO SCREEN 2 ----------------------
; Nao se chama CHPUT em SCREEN 2: cada glifo e um tile de 8x8.
; A arte usa linhas 0-111; texto usa 112-191, sem misturar bancos.
clear_text:
    ld hl,$0E00
    ld bc,2560
    xor a
    call FILVRM
    ld hl,$2E00
    ld bc,2560
    ld a,$F1
    call FILVRM
    ld a,14
    ld (textrow),a
    xor a
    ld (textcol),a
    ret
; tileaddr: A=linha 0..23, C=coluna 0..31 -> DE=VRAM do padrao.
tileaddr:
    ld d,a
    ld e,0
    ld a,c
    add a,a
    add a,a
    add a,a
    ld e,a
    ret
; Renderiza um caractere sem modificar a posicao do cursor.
glyph:
    push af
    push bc
    push de
    push hl
    cp 32
    jr nc,.valid
    ld a,32
.valid:
    cp 128
    jr c,.range
    ld a,'?'
.range:
    sub 32
    ld l,a
    ld h,0
    add hl,hl
    add hl,hl
    add hl,hl
    ld de,font
    add hl,de
    push hl
    ld a,(textcol)
    ld c,a
    ld a,(textrow)
    call tileaddr
    pop hl
    ld bc,8
    call LDIRVM
    pop hl
    pop de
    pop bc
    pop af
    ret
newline:
    xor a
    ld (textcol),a
    ld a,(textrow)
    inc a
    ld (textrow),a
    ret
putc:
    push af
    cp 10
    jr z,.done
    cp 13
    jr z,.nl
    push af
    ld a,(textrow)
    cp 22
    call nc,more
    pop af
    call glyph
    ld a,(textcol)
    inc a
    cp 32
    jr z,.nl
    ld (textcol),a
    jr .done
.nl:
    call newline
.done:
    pop af
    ret
puts:
    ld a,(hl)
    or a
    ret z
    inc hl
    call putc
    jr puts
; Paginacao preserva a ilustracao e o ponteiro da mensagem longa.
more:
    push af
    push bc
    push de
    push hl
    ld a,22
    ld (textrow),a
    xor a
    ld (textcol),a
    ld hl,m_more
.loop:
    ld a,(hl)
    or a
    jr z,.wait
    inc hl
    call glyph
    ld a,(textcol)
    inc a
    ld (textcol),a
    jr .loop
.wait:
    call CHGET
    call clear_text
    pop hl
    pop de
    pop bc
    pop af
    ret
; draw_asset A: cabecalho de 7 bytes; zero encerra, 1..127 literal,
; 129..191 repeticao; 192..255 LZ de 3..66 bytes + distancia DW.
; Dados vao para scratch,
; depois LDIRVM copia retangulos de tiles para padrao e cor do VDP.
draw_asset:
    push af
    push bc
    push de
    push hl
    ld l,a
    ld h,0
    ld d,h
    ld e,l
    add hl,hl
    add hl,hl
    add hl,hl
    or a
    sbc hl,de
    ld de,asset_table
    add hl,de
    ld a,(hl)
    ld ($7000),a
    inc hl
    ld e,(hl)
    inc hl
    ld d,(hl)
    inc hl
    ld a,(hl)
    ld (asset_x),a
    inc hl
    ld a,(hl)
    ld (asset_y),a
    inc hl
    ld a,(hl)
    ld (asset_w),a
    inc hl
    ld a,(hl)
    ld (asset_h),a
    ex de,hl
    ld de,scratch
.unpack:
    ld a,(hl)
    inc hl
    or a
    jr z,.unpacked
    bit 7,a
    jr nz,.repeat
    ld c,a
    ld b,0
    ldir
    jr .unpack
.repeat:
    cp 192
    jr nc,.backref
    and 127
    ld b,a
    ld a,(hl)
    inc hl
.rep:
    ld (de),a
    inc de
    djnz .rep
    jr .unpack
.backref:
    and 63
    add a,3
    ld c,(hl)
    inc hl
    ld b,(hl)
    inc hl
    push hl
    ld h,d
    ld l,e
    or a
    sbc hl,bc
    ld c,a
    ld b,0
    ldir
    pop hl
    jr .unpack
.unpacked:
    ld hl,scratch
    ld (asset_src),hl
    ld a,(asset_x)
    ld c,a
    ld a,(asset_y)
    call tileaddr
    ld (asset_dst),de
    call .plane
    ld a,(asset_x)
    ld c,a
    ld a,(asset_y)
    call tileaddr
    ld a,d
    add a,$20
    ld d,a
    ld (asset_dst),de
    call .plane
    pop hl
    pop de
    pop bc
    pop af
    ret
.plane:
    ld a,(asset_h)
    ld b,a
.row:
    push bc
    ld a,(asset_w)
    add a,a
    add a,a
    add a,a
    ld c,a
    ld b,0
    or a
    jr nz,.width
    inc b                  ; 32 tiles * 8 = 256, nao zero
.width:
    ld hl,(asset_src)
    push hl
    push bc
    ld de,(asset_dst)
    call LDIRVM
    pop bc
    pop hl
    add hl,bc
    ld (asset_src),hl
    ld hl,(asset_dst)
    inc h
    ld (asset_dst),hl
    pop bc
    djnz .row
    ret
show_graphics:
    ld a,(room)
    cp 5
    jp z,scene5
    cp 11
    jp z,scene11
    cp 18
    jp z,scene18
    ld a,(room)
    dec a
    add a,a
    ld l,a
    ld h,0
    ld de,base_assets
    add hl,de
    ld a,(hl)
    call draw_asset
    ld hl,object_art
.loop:
    ld a,(hl)
    or a
    ret z
    ld c,a
    inc hl
    ld a,(hl)
    inc hl
    ld e,(hl)
    inc hl
    inc hl
    push hl
    ld hl,(room)
    ld a,l
    cp c
    jr nz,.next
    dec hl
    ; O objeto esta no byte anterior ao ID do asset, obtido pelo registro.
    pop hl
    push hl
    dec hl
    dec hl
    dec hl
    ld a,(hl)
    push de
    call visible
    pop de
    jr nz,.next
    ld a,e
    call draw_asset
.next:
    pop hl
    jr .loop
; Variantes precompostas evitam que patches sobrepostos apaguem outro
; objeto no mesmo tile SCREEN 2. Cada bit representa uma mudanca visivel.
scene5:
    ld a,(cabdoor)
    ld c,a
    ld a,(loc+15)
    cp 5
    jr nz,.jug
    set 1,c
.jug:
    ld a,(loc+11)
    cp 5
    jr nz,.matches
    set 2,c
.matches:
    ld a,(loc+16)
    cp 5
    jr nz,.snow
    set 3,c
.snow:
    ld a,(snowwall)
    or a
    jr z,.draw
    set 4,c
.draw:
    ld hl,combo5_assets
    jp scene_index
scene18:
    ld a,(paid)
    ld c,a
    ld a,(loc+23)
    cp 18
    jr nz,.shears
    set 1,c
.shears:
    ld a,(loc+24)
    cp 18
    jr nz,.saw
    set 2,c
.saw:
    ld a,(loc+25)
    cp 18
    jr nz,.draw
    set 3,c
.draw:
    ld hl,combo18_assets
    jp scene_index
scene11:
    ld c,0
    ld a,(loc+26)
    cp 11
    jr nz,.feather
    set 0,c
.feather:
    ld a,(loc+34)
    cp 11
    jr nz,.woman
    set 1,c
.woman:
    ld a,(transformed)
    or a
    jr z,.phase
    set 2,c
.phase:
    ld a,(won)
    or a
    jr z,.hood
    cp 1
    jr z,.flames
    set 3,c
.flames:
    set 4,c
    jr .draw
.hood:
    ld a,(voice)
    cp 2
    jr c,.draw
    set 3,c
.draw:
    ld hl,combo11_assets
scene_index:
    ld b,0
    add hl,bc
    ld a,(hl)
    jp draw_asset
; visible retorna Z quando o objeto deve aparecer na sala atual.
visible:
    cp 126
    jr z,.closed
    cp 127
    jr z,.opened
    cp 102
    jr z,.bopen
    cp 96
    jr z,.bopen
    cp 103
    jr z,.bclosed
    cp 113
    jr z,.bclosed
    cp 111
    jr z,.copen
    cp 112
    jr z,.cclosed
    cp 119
    jr z,.organopen
    cp 120
    jr z,.organclosed
    cp 115
    jr z,.old
    cp 99
    jr z,.sleep
    cp 98
    jr z,.statue
    cp 95
    jr z,.hood
    cp 94
    jr z,.fire
    cp 107
    jr z,.altar
    cp 118
    jr z,.yes
    cp 97
    jr z,.snow
    call itemptr
    ld a,(room)
    cp (hl)
    ret
.closed:
    call doorflag
    or a
    ret
.opened:
    call doorflag
    cp 1
    ret
.bopen:
    ld a,(boards)
    cp 1
    ret
.bclosed:
    ld a,(boards)
    or a
    ret
.copen:
    ld a,(coffin)
    cp 1
    ret
.cclosed:
    ld a,(coffin)
    or a
    ret
.organopen:
    ld a,(played)
    cp 1
    ret
.organclosed:
    ld a,(played)
    or a
    ret
.old:
    ld a,(paid)
    or a
    ret
.sleep:
    ld a,(paid)
    cp 1
    ret
.statue:
    ld a,(transformed)
    cp 1
    ret
.hood:
    ld a,(voice)
    cp 2
    jr c,.no
    ld a,(won)
    or a
    ret
.fire:
    ld a,(won)
    cp 1
    ret
.altar:
    ld a,(altar)
    cp 1
    ret
.snow:
    ld a,(snowwall)
    or a
    jr z,.no
    ld a,(cabdoor)
    cp 1
    ret
.yes:
    xor a
    ret
.no:
    ld a,1
    or a
    ret
doorflag:
    ld a,(room)
    cp 9
    ld a,(chapdoor)
    ret z
    ld a,(cabdoor)
    ret
; Animacao por jiffy: neve, fumaca, nuvens, fogo, tochas e olhos.
; Quatro sprites no maximo: respeita o limite de quatro por scanline MSX1.
animate:
    push af
    push bc
    push de
    push hl
    ld a,($FC9E)
    ld c,a
    ld a,(animtick)
    cp c
    jp z,.done
    ld a,c
    ld (animtick),a
    and 7
    jp nz,.done
    ld a,(animframe)
    inc a
    ld (animframe),a
    ld hl,$C300
    ld b,17
    ld (hl),216
.hide:
    ld (hl),216
    inc hl
    djnz .hide
    ld hl,$C300
    ld a,(room)
    cp 5
    jp c,.snow
    jp z,.flame
    cp 11
    jp z,.eyes
    ld de,torch_rooms
.find:
    ld a,(de)
    or a
    jp z,.upload
    ld c,a
    ld a,(room)
    cp c
    jp z,.torches
    inc de
    jp .find
.torches:
    call .color
    ld a,28
    ld c,56
    ld d,2
    call .sprite
    ld a,28
    ld c,184
    call .sprite
    ld a,(room)
    cp 15
    jp z,.upload
    cp 17
    jp z,.upload
    cp 22
    jp z,.upload
    ld a,35
    ld c,96
    call .sprite
    ld a,35
    ld c,152
    call .sprite
    jp .upload
.flame:
    call .color
    ld a,65
    ld c,120
    ld d,2
    call .sprite
    jp .upload
.eyes:
    ld a,(voice)
    cp 2
    jp c,.upload
    ld a,(won)
    or a
    jp nz,.upload
    ld a,33
    ld c,87
    ld d,3
    ld e,8
    call .sprite
    jp .upload
.snow:
    ld a,(animframe)
    ld c,a
    add a,a
    add a,c
    ld c,a
    ld a,(animframe)
    and 63
    add a,4
    ld d,0
    ld e,15
    call .sprite
    ld a,(animframe)
    add a,27
    and 63
    add a,4
    ld c,177
    call .sprite
    ld a,(room)
    cp 1
    jp nz,.cloud
    ld a,(animframe)
    and 7
    ld b,a
    ld a,36
    sub b
    ld c,215
    ld d,1
    ld e,14
    call .sprite
.cloud:
    ld a,(animframe)
    ld c,a
    ld a,12
    ld d,1
    ld e,14
    call .sprite
.upload:
    ld hl,$C300
    ld de,$1B00
    ld bc,17
    call LDIRVM
.done:
    pop hl
    pop de
    pop bc
    pop af
    ret
.color:
    ld a,(animframe)
    and 1
    ld e,10
    ret z
    ld e,8
    ret
.sprite:
    ld (hl),a
    inc hl
    ld (hl),c
    inc hl
    ld (hl),d
    inc hl
    ld (hl),e
    inc hl
    ret
; Editor: linha 23 inteira, 32 caracteres, sem deslocar a ilustracao.
input_line:
    ld a,22
    ld (textrow),a
    xor a
    ld (textcol),a
    ld hl,m_prompt
.prompt:
    ld a,(hl)
    or a
    jr z,.begin
    call glyph
    ld a,(textcol)
    inc a
    ld (textcol),a
    inc hl
    jr .prompt
.begin:
    ld a,23
    ld (textrow),a
    ld hl,buffer
    ld b,0
.wait:
    ; Renova o atraso do BIOS: uma letra por pressionamento fisico.
    ; OLDKEY/NEWKEY continuam reconhecendo soltura e nova pressao,
    ; inclusive letras iguais consecutivas e teclas sobrepostas.
    ld a,255
    ld (REPCNT),a
    call animate
    push bc
    push hl
    call CHSNS
    pop hl
    pop bc
    jr z,.wait
    push bc
    push hl
    call CHGET
    pop hl
    pop bc
    cp 13
    jr z,.done
    cp 8
    jr z,.back
    cp 127
    jr z,.back
    cp 32
    jr c,.wait
    cp 127
    jr nc,.wait
    ld c,a
    ld a,b
    cp 32
    jr nc,.wait
    ld (textcol),a
    ld a,c
    cp 'a'
    jr c,.store
    cp 'z'+1
    jr nc,.store
    sub 32
.store:
    ld (hl),a
    call glyph
    inc hl
    inc b
    jr .wait
.back:
    ld a,b
    or a
    jr z,.wait
    dec hl
    dec b
    ld a,b
    ld (textcol),a
    ld a,32
    call glyph
    jr .wait
.done:
    ld a,b
    or a
    jr z,.zero
    dec hl
    ld a,(hl)
    cp 32
    jr nz,.restore
    dec b
    jr .done
.restore:
    inc hl
.zero:
    ld (hl),0
    ret
lookup_exact:
    ld a,(de)
    or a
    ret z
    push hl
.compare:
    ld a,(de)
    cp (hl)
    jr nz,.miss
    or a
    jr z,.found
    inc de
    inc hl
    jr .compare
.miss:
    ld a,(de)
    inc de
    or a
    jr nz,.miss
    inc de
    pop hl
    jr lookup_exact
.found:
    inc de
    ld a,(de)
    pop hl
    ret

; Busca exata primeiro (aliases portugueses); depois os quatro primeiros
; caracteres, como MAXWRD=4 no original. Palavras curtas seguem exatas.
lookup:
    push hl
    push de
    call lookup_exact
    or a
    jr z,.prefix
    pop de
    pop hl
    ret
.prefix:
    pop de
    pop hl
    push hl
    ld b,4
.length:
    ld a,(hl)
    or a
    jr z,.short
    inc hl
    djnz .length
    pop hl
.entry:
    ld a,(de)
    or a
    ret z
    push hl
    ld b,4
.compare:
    ld a,(de)
    cp (hl)
    jr nz,.skip
    inc de
    inc hl
    djnz .compare
.id:
    ld a,(de)
    inc de
    or a
    jr nz,.id
    ld a,(de)
    pop hl
    ret
.skip:
    ld a,(de)
    inc de
    or a
    jr nz,.skip
    inc de
    pop hl
    jr .entry
.short:
    pop hl
    xor a
    ret
parse:
    xor a
    ld (verb),a
    ld (noun),a
    ld hl,buffer
.lead:
    ld a,(hl)
    cp 32
    jr nz,.begin
    inc hl
    jr .lead
.begin:
    push hl
.split:
    ld a,(hl)
    or a
    jr z,.noun
    cp 32
    jr z,.space
    inc hl
    jr .split
.space:
    ld (hl),0
    inc hl
.trim:
    ld a,(hl)
    cp 32
    jr nz,.noun
    inc hl
    jr .trim
.noun:
    ld (nptr),hl
    pop hl
    ld de,verbs
    call lookup
    ld (verb),a
    ld hl,(nptr)
    ld de,nouns
    call lookup
    ld (noun),a
    ret
itemptr:
    ld l,a
    ld h,0
    ld de,loc
    add hl,de
    ret
has:
    call itemptr
    ld a,(hl)
    cp $FF
    ret
available:
    call itemptr
    ld a,(hl)
    cp $FF
    ret z
    ld a,(room)
    cp (hl)
    ret
lamp_here:
    ld a,(lit)
    or a
    jr z,.no
    ld a,21
    jp available
.no:
    ld a,1
    or a
    ret
message:
    ld (msg),hl
    ret
ok:
    ld hl,m_ok
    jp message
no:
    ld hl,m_no
    jp message
missing:
    ld hl,m_missing
    jp message
full:
    ld hl,m_full
    jp message
; Conta inventario; maximo 5 como MAXOBJ0 no fonte fornecido.
capacity:
    ld hl,loc+9
    ld b,30
    ld c,0
.loop:
    ld a,(hl)
    cp $FF
    jr nz,.next
    inc c
.next:
    inc hl
    djnz .loop
    ld a,c
    cp 5
    ret
roomptr:
    ld a,(room)
    dec a
    ld l,a
    ld h,0
    add hl,hl
    ld d,h
    ld e,l
    add hl,hl
    add hl,de
    ld de,exits
    add hl,de
    ret
show_room:
    call show_graphics
    ld a,(room)
    cp 12
    jr z,.darkcheck
    cp 13
    jr nz,.text
.darkcheck:
    call lamp_here
    jr z,.text
    ld hl,0
    ld bc,3584
    xor a
    call FILVRM
.text:
    call clear_text
    ld hl,m_title
    call puts
    ld a,(room)
    dec a
    add a,a
    ld l,a
    ld h,0
    ld de,descriptions
    add hl,de
    ld e,(hl)
    inc hl
    ld d,(hl)
    ex de,hl
    call puts
    call newline
    ld hl,m_exits
    call puts
    call roomptr
    ld b,6
    ld de,direction_names
.dirs:
    ld a,(hl)
    or a
    jr z,.next
    ld a,(de)
    call putc
    ld a,32
    call putc
.next:
    inc hl
    inc de
    djnz .dirs
    call newline
    ld hl,m_objects
    call puts
    ld a,(room)
    dec a
    add a,a
    ld l,a
    ld h,0
    ld de,scenery
    add hl,de
    ld e,(hl)
    inc hl
    ld d,(hl)
    ex de,hl
    call puts
    ld b,9
.items:
    ld a,b
    call itemptr
    ld a,(room)
    cp (hl)
    jr nz,.skip
    ld a,b
    call itemname
    call puts
    ld a,' '
    call putc
.skip:
    inc b
    ld a,b
    cp 39
    jr c,.items
    call newline
    ret
itemname:
    cp 11
    jr nz,.normal
    ld a,(jug)
    add a,a
    ld l,a
    ld h,0
    ld de,jug_names
    jr .ptr
.normal:
    add a,a
    ld l,a
    ld h,0
    ld de,item_names
.ptr:
    add hl,de
    ld e,(hl)
    inc hl
    ld d,(hl)
    ex de,hl
    ret
dispatch:
    ld a,(verb)
    cp 1
    jp z,examine
    cp 2
    jp z,inventory
    cp 3
    jp z,take
    cp 4
    jp z,drop
    cp 5
    jp c,.bad
    cp 11
    jp c,direction
    jp z,go
    cp 13
    jp z,save_game
    cp 14
    jp z,load_game
    cp 15
    jp z,help
    cp 16
    jp z,score
    cp 17
    jp z,quit
    cp 18
    jp z,open
    cp 19
    jp z,stairs
    cp 20
    jp z,examine
    cp 21
    jp z,play
    cp 22
    jp z,close
    cp 23
    jp z,unlock
    cp 24
    jp z,break_mirror
    cp 25
    jp z,build_altar
    cp 26
    jp z,pull
    cp 27
    jp z,listen
    cp 28
    jp z,cut
    cp 29
    jp z,light
    cp 30
    jp z,unlight
    cp 31
    jp z,wear
    cp 32
    jp z,go
    cp 33
    jp z,drop
    cp 34
    jp z,taste
    cp 35
    jp z,taste
    cp 36
    jp z,dig
    cp 37
    jp z,invoke
    cp 38
    jp z,use
.bad:
    ld hl,m_unknown
    jp message
direction:
    sub 5
    ld c,a
    call roomptr
    ld b,0
    add hl,bc
    ld a,(hl)
    or a
    jp z,no
    jp enter_room
enter_room:
    ld c,a
    ; Escuridao e perigosa, como EXIT12 do original.
    ld a,(room)
    cp 12
    jr z,.risk
    cp 13
    jr nz,.enter
.risk:
    push bc
    call lamp_here
    pop bc
    jr z,.enter
    ld a,(seed)
    and 3
    jp z,dark_death
.enter:
    ld a,c
    ld (room),a
    jp ok
go:
    ld a,(noun)
    cp 7
    jp c,.dir
    cp 110
    jr z,.cabin
    cp 127
    jp z,go_door
    cp 122
    jp z,closet
    cp 121
    jp z,mirror
    cp 124
    jp z,stairs
    cp 114
    jp z,vent
    cp 100
    jp z,passage
    jp no
.dir:
    or a
    jp z,no
    add a,4
    ld (verb),a
    jp direction
.cabin:
    ld a,(room)
    cp 1
    jp nz,go_door
    ld a,4
    jp enter_room
go_door:
    ld a,(room)
    cp 4
    jr z,.cabin
    cp 5
    jr z,.cabin
    cp 6
    jp z,closet
    cp 7
    jr z,.bedroom
    cp 9
    jr z,.chapel
    cp 10
    jr z,.hall
    cp 12
    jr z,.alcove
    cp 23
    jr z,.arch
    jp no
.cabin:
    ld a,(cabdoor)
    or a
    jp z,closed_msg
    ld a,(snowwall)
    or a
    jr nz,.blocked
    ld a,(room)
    xor 1
    jp enter_room
.blocked:
    ld hl,m_snowwall
    jp message
.bedroom:
    ld a,6
    jp enter_room
.chapel:
    ld a,(chapdoor)
    or a
    jp z,locked_msg
    ld a,10
    jp enter_room
.hall:
    ld a,9
    jp enter_room
.alcove:
    ld a,(boards)
    or a
    jp z,boarded_msg
    ld a,23
    jp enter_room
.arch:
    ld a,(boards)
    or a
    jp z,boarded_msg
    ld a,12
    jp enter_room
closet:
    ld a,(room)
    cp 6
    jp nz,no
    ld a,7
    jp enter_room
mirror:
    ld a,(room)
    cp 7
    jr z,.go
    cp 8
    jp nz,no
.go:
    xor 15
    jp enter_room
stairs:
    ld a,(room)
    cp 5
    jr z,.go
    cp 6
    jr z,.go
    cp 17
    jr z,.go
    cp 18
    jr z,.go
    cp 12
    jp z,go_door
    jp no
.go:
    xor 3
    jp enter_room
vent:
    ld a,(room)
    cp 11
    jr z,.small
    cp 12
    jr z,.go
    jp no
.small:
    push af
    ld a,28
    call has
    pop bc
    jr nz,.from11
    ld hl,m_wontfit
    jp message
.from11:
    ld a,11
.go:
    xor 7
    jp enter_room
passage:
    ld a,(played)
    or a
    jp z,no
    ld a,(room)
    cp 10
    jr z,.go
    cp 11
    jp nz,no
.go:
    xor 1
    jp enter_room
; GET respeita invisibilidade, inventario maximo e os eventos originais.
take:
    ld a,(noun)
    cp 128
    jp z,take_all
    cp 35
    jp z,take_note
    cp 31
    jp z,take_sheet
    cp 9
    jp z,take_snow
    cp 10
    jp z,take_needles
    cp 34
    jp z,take_feather
    cp 32
    jp z,take_salt
take_regular:
    ld a,(noun)
    cp 17
    jp z,no
    cp 9
    jp c,no
    cp 39
    jp nc,no
    push af
    call itemptr
    ld a,(room)
    cp (hl)
    jr nz,.missing
    ld a,(noun)
    cp 23
    jr c,.raven
    cp 26
    jr nc,.raven
    ld a,(paid)
    or a
    jr nz,.raven
    ld a,(room)
    cp 18
    jr nz,.raven
    pop af
    ld hl,m_guard
    jp message
.raven:
    ld a,(noun)
    cp 26
    jr nz,.get
    ld a,15
    call has
    jr z,.get
    pop af
    ld hl,m_raven
    jp message
.get:
    call capacity
    jr nc,.full
    pop af
    call itemptr
    ld (hl),$FF
    jp ok
.missing:
    pop af
    jp missing
.full:
    pop af
    jp full
take_all:
    ld b,9
.loop:
    ld a,b
    ld (noun),a
    push bc
    call take_regular
    pop bc
    inc b
    ld a,b
    cp 39
    jr c,.loop
    jp ok
take_note:
    ld a,(room)
    cp 6
    jp nz,take_regular
    ld a,(loc+35)
    cp $FE
    jp nz,take_regular
    ld a,6
    ld (loc+35),a
    jp take_regular
take_sheet:
    ld a,(room)
    cp 6
    jp nz,take_regular
    ld a,(loc+31)
    cp $FE
    jp nz,take_regular
    ld a,6
    ld (loc+31),a
    jp take_regular
take_needles:
    ld a,(room)
    cp 4
    jp nc,take_regular
    ld a,(loc+10)
    cp $FE
    jp nz,take_regular
    ld a,(room)
    ld (loc+10),a
    jp take_regular
take_salt:
    ld a,(room)
    cp 11
    jp nz,take_regular
    ld a,(loc+32)
    cp $FE
    jp nz,take_regular
    ld a,11
    ld (loc+32),a
    jp take_regular
take_feather:
    ld a,(loc+34)
    cp $FE
    jp nz,take_regular
    ld a,26
    call has
    jp nz,missing
    ld a,(room)
    ld (loc+34),a
    jp take_regular
take_snow:
    ld a,(room)
    cp 5
    jp nc,no
    ld a,11
    call has
    jp nz,missing
    ld a,(jug)
    cp 1
    jp nz,no
    ld a,2
    ld (jug),a
    ld a,1
    ld (transformed),a
    ld a,$FE
    ld (loc+17),a
    ld hl,m_jugsnow
    jp message
drop:
    ld a,(noun)
    cp 128
    jp z,drop_all
    cp 9
    jp c,no
    cp 39
    jp nc,no
    push af
    call has
    pop bc
    jp nz,missing
    ld a,b
    call itemptr
    ld a,(room)
    ld (hl),a
    ld a,b
    cp 38
    jr nz,.wine
    ld a,(room)
    cp 11
    jr nz,.wine
    ld a,(voice)
    cp 2
    jr nz,.wine
    ld a,3
    ld (voice),a
    ld hl,m_ashurgent
    jp message
.wine:
    jp ok
drop_all:
    ld hl,loc+9
    ld b,30
.loop:
    ld a,(hl)
    cp $FF
    jr nz,.next
    ld a,(room)
    ld (hl),a
.next:
    inc hl
    djnz .loop
    ld a,(room)
    cp 11
    jr nz,.done
    ld a,(loc+38)
    cp 11
    jr nz,.done
    ld a,(voice)
    cp 2
    jr nz,.done
    inc a
    ld (voice),a
.done:
    jp ok
open:
    ld a,(noun)
    cp 112
    jr z,.coffin
    cp 127
    jp nz,no
    ld a,(room)
    cp 9
    jr z,.chapel
    cp 4
    jr z,.cabin
    cp 5
    jr z,.cabin
    cp 10
    jp z,ok
    jp boarded_msg
.chapel:
    ld a,(chapdoor)
    or a
    jp z,locked_msg
    jp ok
.cabin:
    ld a,1
    ld (cabdoor),a
    jp ok
.coffin:
    ld a,(room)
    cp 13
    jp nz,no
    ld a,1
    ld (coffin),a
    ld hl,m_coffin
    jp message
close:
    ld a,(noun)
    cp 127
    jp nz,no
    ld a,(room)
    cp 4
    jr z,.cabin
    cp 5
    jp nz,no
.cabin:
    xor a
    ld (cabdoor),a
    jp ok
unlock:
    ld a,(noun)
    cp 23
    jr z,.where
    cp 127
    jp nz,no
.where:
    ld a,(room)
    cp 9
    jp nz,no
    ld a,23
    call has
    jp nz,missing
    ld a,1
    ld (chapdoor),a
    jp ok
play:
    ld a,(room)
    cp 10
    jp nz,no
    ld a,(noun)
    cp 37
    jr z,.bach
    ld hl,m_whatplay
    jp message
.bach:
    ld a,20
    call has
    jp nz,missing
    ld a,(played)
    xor 1
    ld (played),a
    call music
    ld hl,m_organ
    jp message
light:
    ld a,(noun)
    cp 21
    jp nz,no
    ld a,21
    call has
    jp nz,missing
    ld a,16
    call has
    jp nz,missing
    ld a,(fuel)
    or a
    jp z,no
    ld a,1
    ld (lit),a
    jp ok
unlight:
    ld a,(noun)
    cp 21
    jp nz,no
    ld a,21
    call has
    jp nz,missing
    xor a
    ld (lit),a
    jp ok
cut:
    ld a,(noun)
    cp 30
    jp nz,no
    ld a,(room)
    cp 6
    jp nz,no
    ld a,(transformed)
    or a
    jp nz,no
    ld a,24
    call has
    jp nz,missing
    ld a,(haircut)
    or a
    jp nz,no
    inc a
    ld (haircut),a
    ld a,6
    ld (loc+30),a
    jp ok
pull:
    ld a,(noun)
    cp 34
    jp z,take_feather
    cp 29
    jp nz,no
    ld a,(room)
    cp 23
    jp nz,no
    ld a,27
    call has
    jp nz,missing
    ld a,(boards)
    or a
    jp nz,no
    inc a
    ld (boards),a
    ld a,23
    ld (loc+28),a
    ld (loc+29),a
    ld hl,m_boards
    jp message
listen:
    ld a,(room)
    cp 13
    jp nz,no
    ld a,(coffin)
    or a
    jp z,no
    ld a,(voice)
    or a
    jp nz,no
    inc a
    ld (voice),a
    ld (snowwall),a
    ld hl,m_bishop
    jp message
build_altar:
    ld a,(noun)
    cp 107
    jp nz,no
    ld a,(room)
    cp 13
    jp nz,no
    ld a,28
    call available
    jp nz,missing
    ld a,29
    call available
    jp nz,missing
    ld a,27
    call available
    jp nz,missing
    ld a,25
    call available
    jp nz,missing
    ld a,$FD
    ld (loc+28),a
    ld (loc+29),a
    ld a,1
    ld (altar),a
    jp ok
invoke:
    ld a,(noun)
    cp 39
    jp nz,no
    ld a,(room)
    cp 24
    jr z,.escape
    cp 11
    jp nz,no
    ld a,(voice)
    cp 3
    jp nz,no
    ld a,1
    ld (won),a
    ld hl,m_victory
    jp message
.escape:
    ld a,7
    ld (room),a
    jp ok
break_mirror:
    ld a,(noun)
    cp 121
    jp nz,no
    ld a,(room)
    cp 7
    jr z,trap
    cp 8
    jp nz,no
trap:
    ld a,24
    ld (room),a
    ld hl,m_trap
    jp message
dig:
    ld a,33
    call has
    jp nz,missing
    ld a,(room)
    cp 6
    jp nc,no
    xor a
    ld (snowwall),a
    jp ok
taste:
    ld a,(noun)
    cp 11
    jr z,.wine
    cp 32
    jp nz,no
    ld hl,m_salty
    jp message
.wine:
    ld hl,m_winetaste
    jp message
use:
    ld a,(noun)
    cp 21
    jp z,light
    cp 23
    jp z,unlock
    cp 24
    jr z,.hair
    cp 27
    jr z,.nails
    cp 18
    jp z,wear
    cp 11
    jp z,drop
    cp 107
    jp z,build_altar
    cp 121
    jp z,mirror
    jp no
.hair:
    ld a,30
    ld (noun),a
    jp cut
.nails:
    ld a,29
    ld (noun),a
    jp pull
wear:
    ld a,18
    call has
    jp z,ok
    ld a,18
    ld (noun),a
    jp take_regular
; ---------------------- EVENTOS POR TURNO ----------------------
after_turn:
    ld a,(won)
    or a
    ret nz
    ld a,(verb)
    or a
    ret z
    cp 2                    ; inventario/ajuda/save/load nao gastam oleo
    ret z
    cp 13
    ret z
    cp 14
    ret z
    cp 15
    ret z
    ld hl,(turns)
    inc hl
    ld (turns),hl
    ld a,(seed)
    add a,17
    rlca
    xor $B8
    ld (seed),a
    ; Velho bebe vinho deixado no sotao e vai dormir na sala 15.
    ld a,(paid)
    or a
    jr nz,.melt
    ld a,(loc+11)
    cp 18
    jr nz,.melt
    ld a,(jug)
    or a
    jr nz,.melt
    ld a,1
    ld (paid),a
    ld (jug),a
    ld a,15
    ld (loc+11),a
    ld hl,m_paid
    ld (msg),hl
.melt:
    ld a,(room)
    cp 5
    jr nz,.ritual
    ld a,11
    call has
    jr nz,.ritual
    ld a,(jug)
    cp 2
    jr nz,.ritual
    inc a
    ld (jug),a
    ld hl,m_water
    ld (msg),hl
.ritual:
    call check_ritual
    ; Oleo acaba depois de 100 acoes com a luz ligada.
    ld a,(lit)
    or a
    jr z,.patrol
    ld a,(fuel)
    or a
    jr z,.out
    dec a
    ld (fuel),a
    jr nz,.patrol
.out:
    xor a
    ld (lit),a
    ld hl,m_out
    ld (msg),hl
.patrol:
    ld a,(room)
    cp 8
    ret c
    cp 24
    ret nc
    cp 11
    ret z
    cp 12
    ret z
    cp 13
    ret z
    cp 18
    ret z
    ld a,(seed)
    and 15
    ret nz
    ld a,18
    call has
    jp nz,trap
    ld hl,m_monk
    jp message
check_ritual:
    ld a,(room)
    cp 13
    ret nz
    ld a,(voice)
    cp 1
    ret nz
    ld a,(altar)
    or a
    ret z
    call lamp_here
    ret nz
    ld a,(jug)
    cp 3
    ret nz
    ld a,11
    call available
    ret nz
    ld hl,ingredients
.check:
    ld a,(hl)
    or a
    jr z,.consume
    inc hl
    push hl
    call available
    pop hl
    ret nz
    jr .check
.consume:
    ld hl,ingredients
.loop:
    ld a,(hl)
    or a
    jr z,.done
    inc hl
    push hl
    call itemptr
    ld (hl),$FD
    pop hl
    jr .loop
.done:
    ld a,1
    ld (jug),a             ; garrafa vazia depois da agua
    xor a
    ld (altar),a
    ld a,13
    ld (loc+38),a
    ld a,2
    ld (voice),a
    ld hl,m_ashes
    jp message
dark_death:
    ld a,2
    ld (won),a
    ld hl,m_darkdeath
    jp message
closed_msg:
    ld hl,m_closed
    jp message
locked_msg:
    ld hl,m_locked
    jp message
boarded_msg:
    ld hl,m_boarded
    jp message
; ---------------------- INSPECAO E INTERFACE ----------------------
examine:
    ld a,(noun)
    or a
    jp z,ok
    cp 128
    jp z,ok
    cp 108
    jp z,look_mantle
    cp 106
    jp z,look_books
    cp 17
    jp z,look_woman
    cp 35
    jp z,.note
    cp 20
    jp z,.music
    cp 19
    jp z,.manu
    cp 105
    jp z,.plaque
    cp 36
    jp z,.emblem
    cp 116
    jp z,.lectern
    cp 114
    jp z,.vent
    cp 112
    jp z,.coffin
    cp 121
    jp z,.mirror
    cp 125
    jp z,.fireplace
    cp 123
    jp z,.bed
    cp 117
    jp z,.salt
    cp 101
    jp z,.pines
    ld hl,m_nothing
    jp message
.fireplace:
    ld a,(room)
    cp 5
    jp nz,no
    ld hl,m_fireplace
    jp message
.bed:
    ld a,(room)
    cp 6
    jp nz,no
    ld hl,m_bed
    jp message
.salt:
    ld a,(room)
    cp 11
    jp nz,no
    ld hl,m_saltcircle
    jp message
.pines:
    ld a,(room)
    cp 4
    jp nc,no
    ld hl,m_pines
    jp message
.note:
    ld a,35
    call has
    jp nz,missing
    ld hl,m_note
    jp message
.music:
    ld a,20
    call has
    jp nz,missing
    ld hl,m_music
    jp message
.manu:
    ld a,19
    call has
    jp nz,missing
    ld hl,m_manu
    jp message
.plaque:
    ld a,(room)
    cp 9
    jp nz,no
    ld hl,m_plaque
    jp message
.emblem:
    ld a,18
    call available
    jp nz,missing
    ld hl,m_emblem
    jp message
.lectern:
    ld a,(room)
    cp 11
    jp nz,no
    ld hl,m_lectern
    jp message
.vent:
    ld a,(room)
    cp 11
    jp z,.ventok
    cp 12
    jp nz,no
.ventok:
    ld hl,m_vent
    jp message
.coffin:
    ld a,(room)
    cp 13
    jp nz,no
    ld hl,m_coffin
    jp message
.mirror:
    ld a,(room)
    cp 7
    jp z,.mirrorok
    cp 8
    jp nz,no
.mirrorok:
    ld hl,m_mirror
    jp message
look_mantle:
    ld a,(room)
    cp 5
    jp nz,no
    ld a,(loc+16)
    cp $FE
    jp nz,ok
    ld a,5
    ld (loc+16),a
    ld hl,m_found
    jp message
look_books:
    ld a,(room)
    cp 20
    jp nz,no
    ld a,(loc+19)
    cp $FE
    jr nz,.music
    ld a,20
    ld (loc+19),a
    ld hl,m_found
    jp message
.music:
    ld a,(loc+20)
    cp $FE
    jp nz,ok
    ld a,20
    ld (loc+20),a
    ld hl,m_found
    jp message
look_woman:
    ld a,(room)
    cp 6
    jp nz,no
    ld a,(transformed)
    or a
    jp nz,no
    ld hl,m_woman
    jp message
inventory:
    call clear_text
    ld hl,m_inventory
    call puts
    ld b,9
.loop:
    ld a,b
    call has
    jr nz,.next
    ld a,b
    call itemname
    call puts
    call newline
.next:
    inc b
    ld a,b
    cp 39
    jr c,.loop
    call more
    ret
help:
    call clear_text
    ld hl,m_help
    call puts
    call more
    ret
score:
    call clear_text
    ld hl,m_score
    call puts
    ; Decimal ate 65535 sem depender do BASIC.
    ld hl,(turns)
    ld de,10000
    call decimal
    ld de,1000
    call decimal
    ld de,100
    call decimal
    ld de,10
    call decimal
    ld a,l
    add a,'0'
    call putc
    call more
    ret
decimal:
    ld a,'0'-1
.loop:
    inc a
    or a
    sbc hl,de
    jr nc,.loop
    add hl,de
    jp putc
quit:
    ld a,2
    ld (won),a
    jp ok
save_game:
    ld hl,$C000
    ld de,$C400
    ld bc,512
    ldir
    ld a,1
    ld ($C600),a
    ld hl,m_saved
    jp message
load_game:
    ld a,($C600)
    cp 1
    jp nz,no
    ld hl,$C400
    ld de,$C000
    ld bc,512
    ldir
    ld hl,m_loaded
    jp message
; Pequena frase de orgao no PSG; registradores do BIOS nao sao assumidos.
music:
    ld hl,notes
.note:
    ld e,(hl)
    inc hl
    ld a,e
    or a
    jr z,.end
    push hl
    xor a
    call WRTPSG
    ld a,1
    ld e,1
    call WRTPSG
    ld a,7
    ld e,$BE              ; canal A, sem ruido, preserva direcao porta MSX
    call WRTPSG
    ld a,8
    ld e,10
    call WRTPSG
    ld b,5
.wait:
    halt
    djnz .wait
    pop hl
    jr .note
.end:
    ld a,8
    ld e,0
    jp WRTPSG
spark_pattern:
    DB $10,$38,$7C,$38,$10,0,0,0 ; floco
    DB $18,$34,$60,$38,$0C,$18,0,0 ; fumaca/nuvem
    DB $10,$18,$38,$2C,$7C,$7E,$3C,$18 ; chama
    DB 0,0,$66,$66,0,0,0,0 ; olhos
torch_rooms: DB 8,9,14,15,16,17,19,21,22,0
notes: DB 85,39,9,39,85,112,85,39,0
ingredients: DB 10,30,31,32,34,0
direction_names: DB "NSLOUD"
font: INCBIN "assets/font.bin"
verbs:
    DB "LOOK",0,1
    DB "L",0,1
    DB "EXAM",0,1
    DB "EXAMINE",0,1
    DB "EXAMINAR",0,1
    DB "OLHAR",0,1
    DB "LER",0,1
    DB "READ",0,1
    DB "INVENTORY",0,2
    DB "INVE",0,2
    DB "I",0,2
    DB "INVENTARIO",0,2
    DB "GET",0,3
    DB "G",0,3
    DB "TAKE",0,3
    DB "GRAB",0,3
    DB "PEGAR",0,3
    DB "PUT",0,4
    DB "DROP",0,4
    DB "P",0,4
    DB "THROW",0,4
    DB "THRO",0,4
    DB "LARGAR",0,4
    DB "SOLTAR",0,4
    DB "JOGAR",0,4
    DB "N",0,5
    DB "NORTH",0,5
    DB "NORT",0,5
    DB "NORTE",0,5
    DB "S",0,6
    DB "SOUTH",0,6
    DB "SOUT",0,6
    DB "SUL",0,6
    DB "E",0,7
    DB "EAST",0,7
    DB "LESTE",0,7
    DB "W",0,8
    DB "WEST",0,8
    DB "O",0,8
    DB "OESTE",0,8
    DB "U",0,9
    DB "UP",0,9
    DB "SUBIR",0,9
    DB "D",0,10
    DB "DOWN",0,10
    DB "DESCER",0,10
    DB "GO",0,11
    DB "WALK",0,11
    DB "RUN",0,11
    DB "IR",0,11
    DB "SAVE",0,13
    DB "SALVAR",0,13
    DB "LOAD",0,14
    DB "CARREGAR",0,14
    DB "HELP",0,15
    DB "AJUDA",0,15
    DB "SCORE",0,16
    DB "PONTOS",0,16
    DB "QUIT",0,17
    DB "SAIR",0,17
    DB "OPEN",0,18
    DB "ABRIR",0,18
    DB "CLIMB",0,19
    DB "CLIM",0,19
    DB "PLAY",0,21
    DB "TOCAR",0,21
    DB "CLOSE",0,22
    DB "CLOS",0,22
    DB "FECHAR",0,22
    DB "UNLOCK",0,23
    DB "UNLO",0,23
    DB "DESTRANCAR",0,23
    DB "BREAK",0,24
    DB "BREA",0,24
    DB "SMASH",0,24
    DB "QUEBRAR",0,24
    DB "BUILD",0,25
    DB "BUIL",0,25
    DB "MAKE",0,25
    DB "CONSTRUIR",0,25
    DB "FAZER",0,25
    DB "PULL",0,26
    DB "PUXAR",0,26
    DB "LISTEN",0,27
    DB "LIST",0,27
    DB "HEAR",0,27
    DB "OUVIR",0,27
    DB "CUT",0,28
    DB "CLIP",0,28
    DB "SAW",0,28
    DB "CORTAR",0,28
    DB "LIGHT",0,29
    DB "LIGH",0,29
    DB "ACENDER",0,29
    DB "UNLIGHT",0,30
    DB "UNLI",0,30
    DB "EXTINGUISH",0,30
    DB "APAGAR",0,30
    DB "WEAR",0,31
    DB "VESTIR",0,31
    DB "ENTER",0,32
    DB "ENTE",0,32
    DB "ENTRAR",0,32
    DB "GIVE",0,33
    DB "DAR",0,33
    DB "TASTE",0,34
    DB "PROVAR",0,34
    DB "DRINK",0,35
    DB "BEBER",0,35
    DB "DIG",0,36
    DB "SHOV",0,36
    DB "CAVAR",0,36
    DB "INVOCARE",0,37
    DB "INVO",0,37
    DB "INVOKE",0,37
    DB "INVOCAR",0,37
    DB "USE",0,38
    DB "USAR",0,38
    DB 0
nouns:
    DB "NORTH",0,1
    DB "NORT",0,1
    DB "NORTE",0,1
    DB "N",0,1
    DB "SOUTH",0,2
    DB "SOUT",0,2
    DB "SUL",0,2
    DB "S",0,2
    DB "EAST",0,3
    DB "LESTE",0,3
    DB "E",0,3
    DB "L",0,3
    DB "WEST",0,4
    DB "OESTE",0,4
    DB "W",0,4
    DB "O",0,4
    DB "UP",0,5
    DB "SUBIR",0,5
    DB "U",0,5
    DB "DOWN",0,6
    DB "DESCER",0,6
    DB "D",0,6
    DB "INVENTORY",0,7
    DB "SNOW",0,9
    DB "NEVE",0,9
    DB "NEEDLES",0,10
    DB "NEED",0,10
    DB "PINHAS",0,10
    DB "AGULHAS",0,10
    DB "JUG",0,11
    DB "WINE",0,11
    DB "VINHO",0,11
    DB "GARRAFA",0,11
    DB "AGUA",0,11
    DB "WATER",0,11
    DB "NET",0,15
    DB "REDE",0,15
    DB "MATCHES",0,16
    DB "MATC",0,16
    DB "FOSFOROS",0,16
    DB "WOMAN",0,17
    DB "GIRL",0,17
    DB "WOMA",0,17
    DB "MULHER",0,17
    DB "HOOD",0,18
    DB "ROBE",0,18
    DB "MANTO",0,18
    DB "MANUSCRIPT",0,19
    DB "MANU",0,19
    DB "MANUSCRITO",0,19
    DB "PARCHMENT",0,20
    DB "PARC",0,20
    DB "MUSIC",0,20
    DB "MUSI",0,20
    DB "PARTITURA",0,20
    DB "LANTERN",0,21
    DB "LANT",0,21
    DB "LAMP",0,21
    DB "LANTERNA",0,21
    DB "KEY",0,23
    DB "KEYS",0,23
    DB "CHAVE",0,23
    DB "CHAVES",0,23
    DB "SHEARS",0,24
    DB "SHEA",0,24
    DB "TESOURA",0,24
    DB "SAW",0,25
    DB "SERROTE",0,25
    DB "RAVEN",0,26
    DB "RAVE",0,26
    DB "CORVO",0,26
    DB "HAMMER",0,27
    DB "HAMM",0,27
    DB "MARTELO",0,27
    DB "BOARDS",0,28
    DB "BOAR",0,28
    DB "TABUAS",0,28
    DB "NAILS",0,29
    DB "NAIL",0,29
    DB "PREGOS",0,29
    DB "HAIR",0,30
    DB "CABELO",0,30
    DB "SHEET",0,31
    DB "SHEE",0,31
    DB "LENCOL",0,31
    DB "SALT",0,32
    DB "SAL",0,32
    DB "SHOVEL",0,33
    DB "SHOV",0,33
    DB "PA",0,33
    DB "FEATHER",0,34
    DB "FEAT",0,34
    DB "PENA",0,34
    DB "MESSAGE",0,35
    DB "MESS",0,35
    DB "NOTE",0,35
    DB "BILHETE",0,35
    DB "EMBLEM",0,36
    DB "EMBL",0,36
    DB "SLEEVE",0,36
    DB "EMBLEMA",0,36
    DB "BACH",0,37
    DB "FUGUE",0,37
    DB "FUGU",0,37
    DB "FUGA",0,37
    DB "ASH",0,38
    DB "ASHES",0,38
    DB "ASHE",0,38
    DB "CINZAS",0,38
    DB "EPISCOPUS",0,39
    DB "EPIS",0,39
    DB "PASSAGE",0,100
    DB "PASS",0,100
    DB "PASSAGEM",0,100
    DB "PINES",0,101
    DB "PINE",0,101
    DB "TREE",0,101
    DB "PINHEIROS",0,101
    DB "SKELETON",0,104
    DB "SKEL",0,104
    DB "ESQUELETO",0,104
    DB "PLAQUE",0,105
    DB "PLAQ",0,105
    DB "BRONZE",0,105
    DB "PLACA",0,105
    DB "BOOKS",0,106
    DB "BOOKCASES",0,106
    DB "BOOK",0,106
    DB "ESTANTES",0,106
    DB "ALTAR",0,107
    DB "ALTA",0,107
    DB "MANTLE",0,108
    DB "MANT",0,108
    DB "PRATELEIRA",0,108
    DB "CABIN",0,110
    DB "CABI",0,110
    DB "CABANA",0,110
    DB "COFFIN",0,112
    DB "COFF",0,112
    DB "CAIXAO",0,112
    DB "VENT",0,114
    DB "DUTO",0,114
    DB "OPENING",0,114
    DB "MAN",0,115
    DB "VELHO",0,115
    DB "LECTERN",0,116
    DB "LECT",0,116
    DB "ATRIL",0,116
    DB "CIRCLE",0,117
    DB "CIRC",0,117
    DB "CIRCULO",0,117
    DB "STATUES",0,118
    DB "STAT",0,118
    DB "ESTATUAS",0,118
    DB "ORGAN",0,120
    DB "ORGA",0,120
    DB "ORGANO",0,120
    DB "ORGAO",0,120
    DB "MIRROR",0,121
    DB "MIRR",0,121
    DB "ESPELHO",0,121
    DB "CLOSET",0,122
    DB "CLOS",0,122
    DB "ARMARIO",0,122
    DB "BED",0,123
    DB "CAMA",0,123
    DB "STAIRS",0,124
    DB "STAI",0,124
    DB "STEPS",0,124
    DB "STEP",0,124
    DB "ESCADA",0,124
    DB "DEGRAUS",0,124
    DB "FIREPLACE",0,125
    DB "FIRE",0,125
    DB "LAREIRA",0,125
    DB "DOOR",0,127
    DB "PORTA",0,127
    DB "ALL",0,128
    DB "EVERYTHING",0,128
    DB "EVER",0,128
    DB "TUDO",0,128
    DB 0
exits:
    DB 2,2,0,2,0,0 ; sala 1
    DB 2,3,2,2,0,0 ; sala 2
    DB 2,2,1,2,0,0 ; sala 3
    DB 0,0,0,1,0,0 ; sala 4
    DB 0,0,0,0,0,0 ; sala 5
    DB 0,0,0,0,0,5 ; sala 6
    DB 0,0,0,6,0,0 ; sala 7
    DB 0,9,0,0,0,0 ; sala 8
    DB 8,0,19,14,0,0 ; sala 9
    DB 9,0,0,0,0,0 ; sala 10
    DB 0,0,0,0,0,0 ; sala 11
    DB 13,0,0,0,0,0 ; sala 12
    DB 0,12,0,0,0,0 ; sala 13
    DB 15,21,9,0,0,0 ; sala 14
    DB 0,14,0,16,0,0 ; sala 15
    DB 19,17,15,0,0,0 ; sala 16
    DB 16,0,0,0,0,0 ; sala 17
    DB 0,0,0,0,0,17 ; sala 18
    DB 20,16,0,9,0,0 ; sala 19
    DB 0,19,21,0,0,0 ; sala 20
    DB 14,22,0,20,0,0 ; sala 21
    DB 21,0,23,0,0,0 ; sala 22
    DB 0,0,0,22,0,0 ; sala 23
    DB 0,0,0,0,0,0 ; sala 24
initial_loc:
    DB 254,254,254,254,254,254,254,254,254,254,254,5,254,254,254,5
    DB 254,6,7,254,254,23,254,18,18,18,11,13,254,254,254,254
    DB 254,4,254,254,254,254,254,254,254,254,254,254,254,254,254,254
    DB 254,254,254,254,254,254,254,254,254,254,254,254,254,254,254,254
    DB 254,254,254,254,254,254,254,254,254,254,254,254,254,254,254,254
    DB 254,254,254,254,254,254,254,254,254,254,254,254,254,254,254,254
    DB 254,254,254,254,254,254,254,254,254,254,254,254,254,254,254,254
    DB 254,254,254,254,254,254,254,254,254,254,254,254,254,254,254,254
item_names:
    DW m_empty,m_empty,m_empty,m_empty,m_empty,m_empty,m_empty,m_empty,m_empty,iname9,iname10,iname11,m_empty,m_empty,m_empty,iname15,iname16,iname17,iname18,iname19,iname20,iname21,m_empty,iname23,iname24,iname25,iname26,iname27,iname28,iname29,iname30,iname31,iname32,iname33,iname34,iname35,m_empty,m_empty,iname38
iname9: DB "NEVE",0
iname10: DB "AGULHAS",0
iname11: DB "VINHO",0
iname15: DB "REDE",0
iname16: DB "FOSFOROS",0
iname17: DB "MULHER",0
iname18: DB "MANTO",0
iname19: DB "MANUSCRITO",0
iname20: DB "PARTITURA",0
iname21: DB "LANTERNA",0
iname23: DB "CHAVES",0
iname24: DB "TESOURA",0
iname25: DB "SERROTE",0
iname26: DB "CORVO",0
iname27: DB "MARTELO",0
iname28: DB "TABUAS",0
iname29: DB "PREGOS",0
iname30: DB "CABELO",0
iname31: DB "LENCOL",0
iname32: DB "SAL",0
iname33: DB "PA",0
iname34: DB "PENA",0
iname35: DB "BILHETE",0
iname38: DB "CINZAS",0
jug_names: DW iname11,jug_empty,jug_snow,jug_water
jug_empty: DB "GARRAFA",0
jug_snow: DB "NEVE/FRASCO",0
jug_water: DB "AGUA",0
descriptions: DW desc1,desc2,desc3,desc4,desc5,desc6,desc7,desc8,desc9,desc10,desc11,desc12,desc13,desc14,desc15,desc16,desc17,desc18,desc19,desc20,desc21,desc22,desc23,desc24
desc1: DB "Montanhas. A neve esta caindo.",0
desc2: DB "Montanhas e pinheiros.",0
desc3: DB "Montanhas e pinheiros.",0
desc4: DB "Entrada da cabana. Neve caindo.",0
desc5: DB "Sala de estar. Lareira acesa.",0
desc6: DB "Quarto fracamente iluminado.",0
desc7: DB "Grande armario de roupas.",0
desc8: DB "Corredor longo e estreito.",0
desc9: DB "Corredor. Placa de bronze.",0
desc10: DB "Sala com teto de catedral.",0
desc11: DB "Sala muito estranha.",0
desc12: DB "Passagem sob o mosteiro.",0
desc13: DB "Cripta subterranea.",0
desc14: DB "Corredor longo e estreito.",0
desc15: DB "Pequena sala.",0
desc16: DB "Corredor longo e estreito.",0
desc17: DB "Fim do corredor. Escada acima.",0
desc18: DB "Sotao no topo da escada.",0
desc19: DB "Corredor longo e estreito.",0
desc20: DB "Antigo estudio.",0
desc21: DB "Corredor longo e estreito.",0
desc22: DB "Fim de um corredor.",0
desc23: DB "Pequena alcova.",0
desc24: DB "Lugar estranho. Estou paralisado.",0
scenery: DW scenery1,scenery2,scenery3,scenery4,scenery5,scenery6,scenery7,scenery8,scenery9,scenery10,scenery11,scenery12,scenery13,scenery14,scenery15,scenery16,scenery17,scenery18,scenery19,scenery20,scenery21,scenery22,scenery23,scenery24
scenery1: DB "PINHEIROS CABANA ",0
scenery2: DB "PINHEIROS ",0
scenery3: DB "PINHEIROS ",0
scenery4: DB "PORTA ",0
scenery5: DB "PORTA ESCADA LAREIRA ",0
scenery6: DB "CAMA ARMARIO ESCADA ",0
scenery7: DB "ESPELHO ",0
scenery8: DB "ESPELHO ",0
scenery9: DB "PORTA PLACA ",0
scenery10: DB "ORGAO ESTATUAS ",0
scenery11: DB "ATRIL CIRCULO ",0
scenery12: DB "DEGRAUS DUTO ",0
scenery13: DB "CAIXAO ",0
scenery14: DB 0
scenery15: DB 0
scenery16: DB 0
scenery17: DB "ESCADA ",0
scenery18: DB "ESCADA VELHO ",0
scenery19: DB 0
scenery20: DB "ESTANTES ",0
scenery21: DB 0
scenery22: DB 0
scenery23: DB "TABUAS PORTA ",0
scenery24: DB "ESTATUAS ",0
m_empty:
    DB 0
m_title:
    DB "BLACK SANCTUM / MSX"
    DB 13
    DB 0
m_welcome:
    DB "AJUDA mostra os comandos."
    DB 13
    DB "Fontes originais: Withers/O Dea."
    DB 13
    DB 0
m_prompt:
    DB "> ENTER confirma / 32 caracteres"
    DB 0
m_more:
    DB "[tecla para continuar]"
    DB 0
m_restart:
    DB 13
    DB "R: REINICIAR."
    DB 0
m_exits:
    DB "SAIDAS: "
    DB 0
m_objects:
    DB "VEJO: "
    DB 0
m_ok:
    DB "Certo."
    DB 0
m_no:
    DB "Nao funciona aqui."
    DB 0
m_missing:
    DB "Objeto ausente ou falta preparo."
    DB 0
m_full:
    DB "So posso carregar cinco objetos."
    DB 0
m_unknown:
    DB "Comando desconhecido. Use AJUDA."
    DB 0
m_closed:
    DB "A porta esta fechada."
    DB 0
m_locked:
    DB "A porta esta trancada."
    DB 0
m_boarded:
    DB "Tabuas e pregos bloqueiam a"
    DB 13
    DB "porta."
    DB 0
m_snowwall:
    DB "Neve profunda bloqueia a porta."
    DB 0
m_wontfit:
    DB "As tabuas nao cabem pelo duto."
    DB 0
m_guard:
    DB "O velho nao deixa. Ele e o"
    DB 13
    DB "zelador."
    DB 0
m_raven:
    DB "O corvo escapa. Preciso da rede."
    DB 0
m_jugsnow:
    DB "A garrafa recebe neve. Um"
    DB 13
    DB "arrepio me atravessa: algo mudou"
    DB 13
    DB "no quarto."
    DB 0
m_ashurgent:
    DB "As cinzas caem no circulo."
    DB 13
    DB "Preciso invocar o bispo"
    DB 13
    DB "IMEDIATAMENTE!"
    DB 0
m_coffin:
    DB "O caixao guarda um esqueleto com"
    DB 13
    DB "vestes de bispo."
    DB 0
m_whatplay:
    DB "O que devo tocar?"
    DB 0
m_organ:
    DB "A fuga de Bach soa. O orgao se"
    DB 13
    DB "move e muda a passagem secreta."
    DB 0
m_boards:
    DB "Pregos retirados! Tabuas e"
    DB 13
    DB "pregos estao no chao. A porta"
    DB 13
    DB "esta livre."
    DB 0
m_bishop:
    DB "O bispo aparece. Preciso de um"
    DB 13
    DB "altar feito por minhas maos,"
    DB 13
    DB "lencol branco, agua pura,"
    DB 13
    DB "agulhas de pinheiro, cabelo de"
    DB 13
    DB "uma jovem, pena negra e sal. Ele"
    DB 13
    DB "pede que eu retorne com tudo"
    DB 13
    DB "isso."
    DB 0
m_victory:
    DB "O predio treme! O circulo arde."
    DB 13
    DB "Um demonio aparece entre as"
    DB 13
    DB "chamas e e banido pela presenca"
    DB 13
    DB "do bispo. VOCE VENCEU!"
    DB 0
m_trap:
    DB "Um vulto me aprisionou. Estou"
    DB 13
    DB "paralisado em outro lugar."
    DB 13
    DB "Lembro das palavras do bilhete?"
    DB 0
m_salty:
    DB "Tem gosto de sal."
    DB 0
m_winetaste:
    DB "O vinho lembra um borgonha."
    DB 0
m_paid:
    DB "O velho pega o vinho e desce."
    DB 13
    DB "Ele dorme na sala pequena; a"
    DB 13
    DB "garrafa vazia ficou la."
    DB 0
m_water:
    DB "A neve derrete na sala aquecida."
    DB 13
    DB "A garrafa agora contem agua"
    DB 13
    DB "pura."
    DB 0
m_ashes:
    DB "O bispo consagra o altar. As"
    DB 13
    DB "chamas o transformam em cinzas!"
    DB 13
    DB "Devo jogar as cinzas no circulo"
    DB 13
    DB "e invocar o bispo imediatamente."
    DB 0
m_out:
    DB "A lanterna ficou sem oleo!"
    DB 0
m_monk:
    DB "Um monge encapuzado passa, acena"
    DB 13
    DB "para meu manto e segue adiante."
    DB 0
m_darkdeath:
    DB "Tropecei no escuro e bati a"
    DB 13
    DB "cabeca. A aventura terminou."
    DB 0
m_stone:
    DB "Os encapuzados me arrastam ao"
    DB 13
    DB "circulo. Fui transformado em"
    DB 13
    DB "pedra!"
    DB 0
m_nothing:
    DB "Nao vejo nada de especial."
    DB 0
m_note:
    DB "O bilhete diz: Eles estao atras"
    DB 13
    DB "de mim. Lembre-se: INVOCARE"
    DB 13
    DB "EPISCOPUS."
    DB 0
m_music:
    DB "Uma fuga de Bach escrita no"
    DB 13
    DB "pergaminho."
    DB 0
m_manu:
    DB "8 de junho de 1781: o bispo"
    DB 13
    DB "morreu de peste e foi sepultado"
    DB 13
    DB "na cripta. Os irmaos decidiram"
    DB 13
    DB "fechar o mosteiro."
    DB 0
m_plaque:
    DB "Mosteiro de Sao Sebastiao, 1739."
    DB 0
m_emblem:
    DB "Um pentaculo invertido na manga."
    DB 0
m_lectern:
    DB "Um pentaculo invertido no atril."
    DB 13
    DB "Ha uma abertura atras dele."
    DB 0
m_vent:
    DB "Parece um grande duto de ar."
    DB 0
m_mirror:
    DB "Um espelho antigo de corpo"
    DB 13
    DB "inteiro."
    DB 0
m_found:
    DB "Encontrei algo escondido!"
    DB 0
m_woman:
    DB "Uma jovem de cabelo longo e"
    DB 13
    DB "escuro esta em transe. Segura um"
    DB 13
    DB "bilhete."
    DB 0
m_inventory:
    DB "INVENTARIO (limite 5):"
    DB 13
    DB 0
m_help:
    DB "COMANDOS CLASSICOS"
    DB 13
    DB "N S E W U D / IR NORTE"
    DB 13
    DB "L = LOOK. Leste: E ou IR LESTE."
    DB 13
    DB "GO/IR CABIN, DOOR, STAIRS,"
    DB 13
    DB "CLOSET, MIRROR, PASSAGE, VENT."
    DB 13
    DB "LOOK / EXAMINAR objeto"
    DB 13
    DB "GET / PEGAR; DROP / LARGAR"
    DB 13
    DB "GET ALL / DROP ALL"
    DB 13
    DB "OPEN / ABRIR; CLOSE / FECHAR"
    DB 13
    DB "UNLOCK / DESTRANCAR PORTA"
    DB 13
    DB "PLAY / TOCAR BACH"
    DB 13
    DB "LIGHT / ACENDER LANTERNA"
    DB 13
    DB "UNLIGHT / APAGAR LANTERNA"
    DB 13
    DB "CUT / CORTAR CABELO"
    DB 13
    DB "PULL / PUXAR PREGOS"
    DB 13
    DB "BUILD / CONSTRUIR ALTAR"
    DB 13
    DB "LISTEN / OUVIR"
    DB 13
    DB "DIG / CAVAR NEVE"
    DB 13
    DB "INVOCARE EPISCOPUS"
    DB 13
    DB "I = INVENTARIO; SCORE = TURNOS"
    DB 13
    DB "SAVE / LOAD: copia na RAM."
    DB 13
    DB "Para salvar em disco, use o"
    DB 13
    DB "savestate do emulador."
    DB 13
    DB "A lanterna dura 100 acoes acesa."
    DB 13
    DB "Graficos em SCREEN 2, 256x192."
    DB 0
m_score:
    DB "TURNOS: "
    DB 0
m_saved:
    DB "Estado copiado na RAM (SAVE)."
    DB 0
m_loaded:
    DB "Estado restaurado da RAM (LOAD)."
    DB 0
m_fireplace:
    DB "Pedras grandes sustentam uma"
    DB 13
    DB "prateleira de madeira sobre a"
    DB 13
    DB "lareira."
    DB 0
m_bed:
    DB "Uma cama grande com lencol"
    DB 13
    DB "branco."
    DB 0
m_saltcircle:
    DB "O circulo desenhado no chao e"
    DB 13
    DB "feito de sal."
    DB 0
m_pines:
    DB "Agulhas de pinheiro cobrem o"
    DB 13
    DB "chao."
    DB 0
    INCLUDE "assets/tables.inc"
    ASSERT $ <= $8000
    DS $8000-$,$FF
    ORG $8000
    INCBIN "assets/bank01.bin"
    ORG $8000
    INCBIN "assets/bank02.bin"
    ORG $8000
    INCBIN "assets/bank03.bin"
    ORG $8000
    INCBIN "assets/bank04.bin"
    ORG $8000
    INCBIN "assets/bank05.bin"
    ORG $8000
    INCBIN "assets/bank06.bin"
    ORG $8000
    INCBIN "assets/bank07.bin"
    ORG $8000
    INCBIN "assets/bank08.bin"
    ORG $8000
    INCBIN "assets/bank09.bin"
    ORG $8000
    INCBIN "assets/bank10.bin"
    ORG $8000
    INCBIN "assets/bank11.bin"
    ORG $8000
    INCBIN "assets/bank12.bin"
    ORG $8000
    DS 16384,$FF
    ORG $8000
    DS 16384,$FF
    ORG $8000
    DS 16384,$FF
    ASSERT $ == $C000
