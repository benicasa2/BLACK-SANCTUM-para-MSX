# The Black Sanctum — MSX Graphic Edition

Adventure gráfico em **Assembly Z80**, para **MSX1/MSX2 com 64 KB de RAM e 16 KB de VRAM**, baseado nos arquivos fornecidos nesta conversa. Cartucho **ASCII16, 256 KB**. A ROM, o fonte e os dados gráficos estão completos neste pacote.

O jogo mantém a exploração por comandos, o inventário de cinco objetos, os enigmas encadeados e a sequência de banimento dos fontes enviados. Esta edição substitui a adaptação anterior que usava apenas texto e um mapa aproximado.

## Teclado corrigido em 21/10/2026

O editor renova REPCNT (F3F7h), contador de auto-repeat do BIOS, durante a espera por entrada. Assim, manter uma tecla pressionada nao insere letras repetidas; solte e pressione novamente para repetir uma letra ou Backspace. As transicoes de teclas continuam sob controle do BIOS, incluindo digitacao com teclas sobrepostas. A fonte pequena 5x7 permanece nesta versao.

Teste por matriz fisica emulada no openMSX, com BIOS MSX1 e MSX2: manter A por 1,6 segundo produziu A (a versao anterior produzia AAAAA); dois toques produziram AA; Backspace editou ABB para AB; Enter mantido enviou um unico comando; teclas sobrepostas produziram ABB corretamente. O roteiro de 230 comandos tambem chegou a vitoria em C-BIOS_MSX1 e C-BIOS_MSX2.

## Fonte corrigida em 21/10/2026

A fonte foi reduzida para **5×7 pixels**, com margens dentro de cada tile de 8×8. Todos os glifos têm a última linha livre e margens laterais; não há caracteres recortados. A apresentação usa letras maiúsculas para manter a legibilidade nessa grade. O jogo continua aceitando comandos em maiúsculas e minúsculas. Carregue a ROM com o novo nome `SANCTUM-GFX-TECLADO-CORRIGIDO.rom` para receber a correção.

## Jogar agora

Extraia o ZIP. No openMSX, abra `SANCTUM-GFX-TECLADO-CORRIGIDO.rom` como cartucho **ASCII16** e reinicie. Pela linha de comando:

```text
openmsx -cart SANCTUM-GFX-TECLADO-CORRIGIDO.rom -romtype ASCII16
```

Uma configuração testada, que utiliza o BIOS livre incluído no openMSX:

```text
openmsx -machine C-BIOS_MSX1 -cart SANCTUM-GFX-TECLADO-CORRIGIDO.rom -romtype ASCII16
```

Também foi testado o mesmo comando com `C-BIOS_MSX2`. A abertura e inicialização são automáticas; não use `RUN` ou `BLOAD` para esta ROM.

No WebMSX, extraia o ZIP e carregue **somente `SANCTUM-GFX-TECLADO-CORRIGIDO.rom`** no slot de cartucho. Selecione o formato ASCII16 caso seja solicitado, uma máquina MSX com 64 KB e reinicie. Esta edição foi testada no openMSX, não no WebMSX.

Em hardware físico, use um cartucho regravável/flash que ofereça o mapper ASCII16. Uma ROM normal de 16 KB ou um carregador BLOAD não substituem esse mapper. Não houve teste em computador físico.

## Como jogar

Digite um verbo e um objeto, depois ENTER. Comandos em inglês preservam o vocabulário histórico; há aliases em português, sem acentos. Maiúsculas/minúsculas são aceitas. BACKSPACE edita a entrada, limitada a 32 caracteres.

| Comando | Função |
|---|---|
| `N`, `S`, `E`, `W`, `U`, `D` | Norte, sul, leste, oeste, subir, descer |
| `IR NORTE`, `IR LESTE`, `IR OESTE` | Equivalentes em português |
| `L` ou `LOOK` | Observar o local; **L é LOOK**, como no original |
| `GO CABIN`, `GO DOOR`, `GO STAIRS` | Entrar na cabana, porta e escada |
| `GO CLOSET`, `GO MIRROR` | Armário e espelho |
| `GO PASSAGE`, `GO VENT` | Passagem secreta e duto |
| `LOOK WOMAN`, `EXAMINAR MULHER` | Examinar um objeto ou personagem |
| `GET`, `PEGAR`; `DROP`, `LARGAR` | Recolher e deixar objetos |
| `GET ALL`, `DROP ALL` | Recolher/deixar os objetos disponíveis |
| `OPEN DOOR`, `CLOSE DOOR` | Abrir/fechar a porta da cabana |
| `UNLOCK DOOR` | Destrancar a porta do mosteiro com as chaves |
| `PLAY BACH`, `PLAY FUGUE` | Tocar a fuga específica, com a partitura |
| `LIGHT LANTERN`, `UNLIGHT LANTERN` | Acender/apagar a lanterna |
| `CUT HAIR`, `PULL NAILS` | Cortar cabelo; retirar os pregos |
| `BUILD ALTAR`, `LISTEN` | Construir o altar; ouvir o bispo |
| `DIG SNOW` | Remover a neve que bloqueia a porta, com a pá |
| `INVOCARE EPISCOPUS` | Invocação do bilhete |
| `I`, `INVENTARIO` | Mostrar inventário |
| `AJUDA`, `HELP`; `SCORE` | Comandos disponíveis; contador de ações |
| `SAVE`, `LOAD` | Uma cópia de segurança na RAM durante a sessão |

Para abreviar, os primeiros quatro caracteres também identificam palavras, como no parser histórico. A busca exata tem prioridade para evitar colisões dos aliases em português. Exemplos: `LOOK MANT`, `GET PARC`, `UNLO DOOR`.

Use **E** para leste quando digitar apenas uma letra. `L` foi reservado ao LOOK original. O parser permite `IR LESTE` sem ambiguidade.

A ilustração ocupa a parte superior. Abaixo ficam descrição, saídas, objetos e respostas. Mensagens longas mostram `[tecla para continuar]`; pressione uma tecla para ler a próxima página. Essa tecla não é um comando.

O manto protege quando está no inventário; `WEAR ROBE` equivale a recolhê-lo. A lanterna dura **100 ações enquanto acesa**; apague-a fora da passagem subterrânea e da cripta. O inventário tem **cinco posições**: deixar objetos no chão é parte da solução, não os destrói.

Na vitória ou morte, pressione `R` para recomeçar. `SAVE` copia o estado para RAM e `LOAD` o restaura, mas **RESET/fechar o emulador apaga essa cópia**. Para salvar permanentemente, use o recurso de salvar estado do emulador.

## O que foi extraído dos fontes

Apesar da identificação inicial como CoCo, os arquivos fornecidos são da versão **IBM PC 8086/8088**, com segmentos DOS, chamadas `INT 21h`, memória CGA em `B800h` e cabeçalho de versão 1.4. Os créditos nomeiam **Bob Withers e Stephen O'Dea / Mark Data Products**. Esta edição é um porte para Z80 dessa referência, não uma compilação direta de Assembly 6809.

Foram lidas as tabelas e rotinas, sem executar código dos anexos:

- `ADVDATA2.ASM`: topologia, objetos, vocabulário, telas e posições das camadas.
- `ADVCODE2.ASM`: portas, neve, velho, órgão, cabelo, duto, caixão, altar, ingredientes, cinzas e invocação.
- `SCREENS.ASM` e `ADVOVL1.ASM`: 157 blocos comprimidos e 146 definições de camadas.
- `ADVSYS11.ASM`: interpretação do formato gráfico e de sua compressão.

O mapa real desses arquivos tem **23 locais exploráveis e uma sala 24 de aprisionamento**. Ele difere do mapa digitado anteriormente: por exemplo, a porta da sala 9 é atravessada por `GO DOOR`, enquanto oeste leva a 14; o atalho das tábuas liga **23 a 12**; o duto liga **11 a 12**. O mapa implementado está em `MAPA.md`.

## Gráficos atualizados

Os desenhos preservam enquadramentos e formas das composições extraídas: cabana, cama, espelho, órgão, atril, corredores, caixão e sótão. Não são ilustrações genéricas substituindo as salas.

A edição aplica **Scale2x**, recoloração por ambiente e texturas de pedra/madeira; depois converte o resultado para as restrições reais do SCREEN 2. Os objetos recolhidos e os estados de porta, órgão, velho, caixão, altar e ritual mudam a imagem. As salas com camadas que compartilham tiles têm variantes precompostas, evitando apagar um objeto ao atualizar outro.

- Tela MSX: **256×192**, paleta de 16 cores do MSX.
- Ilustração: **256×112**; interface: **256×80**.
- Desenho de referência: dados efetivos de **128×90**, ampliados horizontalmente pelo renderer CGA.
- A melhoria refere-se à grade efetiva das ilustrações. A tela total de um MSX1 não supera a resolução nominal de 320×200 do modo CGA do PC.
- A limitação de duas cores por grupo de oito pixels em cada linha é respeitada nos arquivos de padrões/cores.
- Sprites animam neve, fumaça, nuvens, fogo, tochas e olhos, sem consumir turnos e sem exceder quatro sprites na mesma linha.
- O órgão tem uma frase sonora curta no PSG, uma adição desta edição; não é uma gravação ou reprodução integral da fuga.

`PREVIA.png` reúne quatro telas reconstruídas da VRAM gerada durante o teste no openMSX. `GALERIA-MSX.png` mostra a arte das 24 salas. `galeria/JOGO-XX.png` mostra estados efetivamente alcançados no roteiro. A pasta `referencias` contém uma comparação reconstruída das composições do fonte.

## Enigmas preservados

Há fósforos escondidos na prateleira da lareira e documentos escondidos nas estantes. O velho bebe o vinho deixado no sótão e vai para a sala 15, onde deixa a garrafa vazia. Só então permite recolher ferramentas. O órgão exige a partitura e a identificação da fuga de Bach. O espelho funciona nos dois sentidos e pode aprisionar quem tenta quebrá-lo; a invocação permite escapar da sala 24.

A rede permite capturar o corvo; dele se retira a pena. A tesoura deixa uma mecha no chão, que precisa ser recolhida **antes** de a mulher ser transformada em estátua. Neve na garrafa vazia derrete na sala de estar. A pá remove o bloqueio de neve da porta. O martelo retira os pregos da passagem na alcova; tábuas, pregos, martelo e serrote permitem construir o altar na cripta. As tábuas não passam pelo duto.

O caixão é aberto sem exigir martelo, conforme `OPEN02` do fonte. `LISTEN` apresenta o pedido do bispo: **água, cabelo, lençol branco, agulhas de pinheiro, pena e sal**. Com esses ingredientes presentes ou carregados na cripta iluminada e o altar construído, a consagração acontece automaticamente. Recolha as cinzas, jogue-as no círculo e invoque imediatamente. Um comando de exploração entre jogar as cinzas e invocar causa petrificação.

## Diferenças deliberadas

Esta é uma adaptação fiel às regras centrais extraídas, não uma promessa de equivalência binária ou de cada mensagem/temporização:

- Textos foram traduzidos e resumidos para o painel de 32 colunas, com aliases novos.
- SAVE/LOAD de disco DOS, dez posições, foi substituído por uma cópia na RAM e pelo salvamento de estado do emulador.
- Seleção de monitor CGA, proteção de cópia e teclas de pânico do PC não são transportadas.
- Animações foram reimplementadas por sprites; não reproduzem os mesmos deslocamentos de bytes da CGA.
- Encontros de patrulha usam uma sequência pseudoaleatória própria. A captura sem manto é recuperável pela sala 24, sem a morte aleatória adicional de algumas capturas do fonte.
- Inventário, ajuda e SAVE/LOAD não gastam combustível nesta edição.
- A advertência numérica a cada turno nos últimos 19 turnos da lanterna não foi reproduzida; o esgotamento e a escuridão continuam ativos.

## Compilar

Instale o SjASMPlus e mantenha a pasta `assets` ao lado do fonte. Não é preciso Python, DOS, BASIC, imagens externas ou os fontes PC para montar o cartucho:

```text
sjasmplus -Wno-fileorg --raw=SANCTUM-GFX-TECLADO-CORRIGIDO.rom --sym=SANCTUM-GFX.sym SANCTUM-GFX.asm
```

Ou execute `COMPILAR.cmd` no Windows, com `sjasmplus.exe` no PATH. Testado com **SjASMPlus 1.24.0**. O resultado tem exatamente **262.144 bytes**. A opção `-Wno-fileorg` desativa somente o aviso esperado dos bancos que compartilham a origem lógica `8000h`; os bancos são concatenados no arquivo e não devem receber intervalos de preenchimento entre eles. Os demais avisos permanecem habilitados.

O fonte usa diretivas e sintaxe do SjASMPlus; não se afirma compatibilidade direta com o montador diferente chamado z80asm.

## Memória e implementação

| Região | Conteúdo |
|---|---|
| `0000h–3FFFh` | BIOS |
| `4000h–7FFFh` | Banco 0 fixo: programa, textos, tabelas e fonte |
| `8000h–BFFFh` | Janela ASCII16 para gráficos; seleção por escrita em `7000h` |
| `C000h–C1FFh` | Estado, buffer de entrada, localizações dos objetos |
| `C300h–C310h` | Atributos temporários dos sprites |
| `C400h–C5FFh` | Cópia SAVE na RAM |
| `C600h` | Marcador da cópia SAVE |
| `C800h–E3FFh` | Descompressão de um asset, máximo 7.168 bytes |
| Abaixo de `F000h` | Pilha própria; variáveis do BIOS acima de `F380h` preservadas |

O código descobre o slot primário/secundário do cartucho e usa `ENASLT` para mapear a janela gráfica sem remover o BIOS ou a RAM da página 3. `CHGMOD`, `LDIRVM` e `FILVRM` cuidam do VDP; `CHSNS`/`CHGET` mantêm o teclado padrão. Em SCREEN 2 os caracteres são tiles, por isso `CHPUT` não é usado para desenhar texto. Interrupções do BIOS ficam habilitadas durante a entrada. `WRTPSG` produz o som.

São 255 assets, comprimidos com literais, repetições e referências LZ, distribuídos em 12 bancos gráficos. O primeiro banco tem o código; os bancos restantes completam os 256 KB. `assets/manifest.json` identifica os dados e os estados das variantes; `FORMATO-GRAFICO.md` explica sua organização.

## Validação

Montagem sem erros nem avisos com o comando documentado. O roteiro de **230 comandos** foi executado literalmente até a vitória, passando por **24/24 salas**, no núcleo Z80 de teste e no **openMSX 21.0 com C-BIOS MSX1 e C-BIOS MSX2**. Ao final, a lanterna conservava 29 ações de combustível. Os testes do núcleo também conferiram descompressão e transferências VRAM de todos os 255 assets, inventário, parser, SAVE/LOAD e o prazo da invocação.

Veja `VALIDACAO-NUCLEO.txt`, `VALIDACAO-C-BIOS_MSX1.txt` e `VALIDACAO-C-BIOS_MSX2.txt`. Esses resultados confirmam as configurações testadas; não equivalem a teste em hardware físico, WebMSX ou em todos os BIOS proprietários.
