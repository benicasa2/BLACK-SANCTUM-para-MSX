# Mapa extraido de ADVDATA2.ASM

As seis direcoes abaixo copiam RMTBDF, inclusive o labirinto de montanha. Zero significa ausencia de saida direcional; portas, escadas e portais tambem podem exigir comandos GO especificos. A numeração e a do fonte fornecido, e nao a do mapa aproximado da primeira mensagem.

|Sala|Local|N|S|E|W|U|D|
|---|---|---|---|---|---|---|---|
|1|Montanha / cabana distante|2|2|—|2|—|—|
|2|Montanha / pinheiros|2|3|2|2|—|—|
|3|Montanha / pinheiros|2|2|1|2|—|—|
|4|Entrada da cabana|—|—|—|1|—|—|
|5|Sala de estar|—|—|—|—|—|—|
|6|Quarto|—|—|—|—|—|5|
|7|Armario|—|—|—|6|—|—|
|8|Corredor / espelho|—|9|—|—|—|—|
|9|Corredor / placa|8|—|19|14|—|—|
|10|Sala do orgao|9|—|—|—|—|—|
|11|Sala do circulo|—|—|—|—|—|—|
|12|Passagem em arco|13|—|—|—|—|—|
|13|Cripta|—|12|—|—|—|—|
|14|Corredor|15|21|9|—|—|—|
|15|Pequena sala|—|14|—|16|—|—|
|16|Corredor|19|17|15|—|—|—|
|17|Fim de corredor / escada|16|—|—|—|—|—|
|18|Sotao|—|—|—|—|—|17|
|19|Corredor leste|20|16|—|9|—|—|
|20|Estudio|—|19|21|—|—|—|
|21|Corredor de ligacao|14|22|—|20|—|—|
|22|Fim de corredor|21|—|23|—|—|—|
|23|Alcova|—|—|—|22|—|—|
|24|Aprisionamento|—|—|—|—|—|—|

## Conexoes por comandos

| Comando | Salas | Condicao |
|---|---|---|
| GO CABIN | 1 → 4 | Cabana visivel |
| GO DOOR | 4 ↔ 5 | Porta aberta e neve removida |
| GO STAIRS | 5 ↔ 6 | Escada da cabana |
| GO CLOSET / GO DOOR | 6 → 7 | Entrada do armario |
| W / GO DOOR | 7 → 6 | Retorno ao quarto |
| GO MIRROR | 7 ↔ 8 | Espelho |
| GO DOOR | 9 ↔ 10 | Chaves destrancam em 9 |
| GO PASSAGE | 10 ↔ 11 | Fuga de Bach move o orgao |
| GO VENT | 11 ↔ 12 | As tabuas nao cabem na ida de 11 |
| GO STAIRS / GO DOOR | 12 ↔ 23 | Pregos retirados do lado 23 |
| N / S | 12 ↔ 13 | Lanterna recomendada; escuro pode matar |
| GO STAIRS | 17 ↔ 18 | Escada do sotao |
| INVOCARE EPISCOPUS | 24 → 7 | Escapa do aprisionamento |

O atalho A do mapa esquematico esta representado pela ligacao N/S entre 16 e 19. O atalho B e a porta 12/23, nao uma ligacao 13/23. No jogo se usam comandos e direcoes; `IR A` e `IR B` da adaptacao anterior nao sao comandos desta edicao.
